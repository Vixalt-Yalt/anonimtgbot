import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    BOT_TOKEN = os.getenv('BOT_TOKEN')
    
    if not BOT_TOKEN:
        print("❌ ВНИМАНИЕ: BOT_TOKEN не установлен в .env файле!")
        print("   Создайте файл .env с содержимым:")
        print("   BOT_TOKEN=ваш_токен_здесь")
        print("   BOT_PASSWORD=ваш_пароль")
        print("   DB_NAME=anonim.db")
        raise ValueError("BOT_TOKEN не установлен в .env файле!")
    
    DB_NAME = os.getenv('DB_NAME', 'anonim.db')
    
    BOT_PASSWORD = os.getenv('BOT_PASSWORD')
    
    if not BOT_PASSWORD:
        print("❌ ВНИМАНИЕ: BOT_PASSWORD не установлен в .env файле!")
        print("   Добавьте в файл .env строку:")
        print("   BOT_PASSWORD=ваш_пароль")
        raise ValueError("BOT_PASSWORD не установлен в .env файле!")
    
    ROLES_FILE = 'roles.txt'
    
    REQUEST_TIMEOUT = 90
    READ_TIMEOUT = 180
    WRITE_TIMEOUT = 180
    CONNECT_TIMEOUT = 90
    POOL_TIMEOUT = 120
    
    MAX_POST_LENGTH = 4000
    MAX_TAG_COUNT = 50
    TAG_COOLDOWN = 300
    
    LOG_LEVEL = 'INFO'
    LOG_FILE = 'anonim.log'
    
    MAX_TOPICS = 50

if __name__ == '__main__':
    print("✅ Конфигурация загружена")
    print(f"   • Токен: {Config.BOT_TOKEN[:10]}...")
    print(f"   • Пароль: {'*' * len(Config.BOT_PASSWORD)} (скрыт)")
    print(f"   • База данных: {Config.DB_NAME}")
    print(f"   • Файл ролей: {Config.ROLES_FILE}")
    print(f"   • Файл логов: {Config.LOG_FILE}")