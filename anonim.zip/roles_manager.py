import os
import logging
import re
from config import Config

logger = logging.getLogger(__name__)

class RolesManager:
    
    @staticmethod
    def load_roles():
        """Загружает роли из файла"""
        roles = {}
        
        if not os.path.exists(Config.ROLES_FILE):
            logger.warning(f"Файл {Config.ROLES_FILE} не найден. Создаю пример файла.")
            example_roles = {
                "Администратор": ["admin1", "admin2"],
                "Разработчик": ["dev1", "dev2", "dev3"],
                "Дизайнер": ["designer1", "designer2"]
            }
            RolesManager.save_roles(example_roles)
            return example_roles
        
        try:
            with open(Config.ROLES_FILE, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                
            for line in lines:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                if ' - ' in line:
                    parts = line.split(' - ', 1)
                elif ' — ' in line:
                    parts = line.split(' — ', 1)
                elif ' – ' in line:
                    parts = line.split(' – ', 1)
                elif ': ' in line:
                    parts = line.split(': ', 1)
                else:
                    continue
                
                if len(parts) == 2:
                    role_name = parts[0].strip()
                    usernames_str = parts[1].strip()
                    
                    usernames = []
                    for username in usernames_str.split(','):
                        username = username.strip()
                        if username:
                            if username.startswith('@'):
                                username = username[1:]
                            usernames.append(username)
                    
                    if role_name and usernames:
                        roles[role_name] = usernames
            
            logger.info(f"Загружено {len(roles)} ролей из {Config.ROLES_FILE}")
            return roles
            
        except Exception as e:
            logger.error(f"Ошибка загрузки ролей: {e}")
            return {}
    
    @staticmethod
    def save_roles(roles):
        """Сохраняет роли в файл"""
        try:
            with open(Config.ROLES_FILE, 'w', encoding='utf-8') as f:
                for role_name, usernames in roles.items():
                    usernames_str = ", ".join([f"@{u}" for u in usernames])
                    f.write(f"{role_name} - {usernames_str}\n")
            
            logger.info(f"Сохранено {len(roles)} ролей в {Config.ROLES_FILE}")
            return True
        except Exception as e:
            logger.error(f"Ошибка сохранения ролей: {e}")
            return False
    
    @staticmethod
    def get_role_names():
        """Возвращает список названий ролей"""
        roles = RolesManager.load_roles()
        return list(roles.keys())
    
    @staticmethod
    def get_usernames_by_role(role_name):
        """Возвращает список юзернеймов для указанной роли"""
        roles = RolesManager.load_roles()
        return roles.get(role_name, [])
    
    @staticmethod
    def format_mentions_for_role(role_name):
        """Форматирует упоминания для роли"""
        usernames = RolesManager.get_usernames_by_role(role_name)
        if not usernames:
            return f"👥 <b>Участники с ролью '{role_name}':</b>\n(никто не найден)\n\n"
        
        mentions = [f"@{username}" for username in usernames]
        return f"👥 <b>Участники с ролью '{role_name}':</b>\n" + ", ".join(mentions) + "\n\n"
    
    @staticmethod
    def add_role(role_name, usernames):
        """Добавляет новую роль"""
        roles = RolesManager.load_roles()
        roles[role_name] = usernames
        return RolesManager.save_roles(roles)
    
    @staticmethod
    def remove_role(role_name):
        """Удаляет роль"""
        roles = RolesManager.load_roles()
        if role_name in roles:
            del roles[role_name]
            return RolesManager.save_roles(roles)
        return False