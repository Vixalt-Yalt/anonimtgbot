from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from roles_manager import RolesManager

class Keyboards:
    @staticmethod
    def main_menu():
        """Основное меню"""
        keyboard = [
            [InlineKeyboardButton("📝 Создать пост", callback_data="/create_post")],
            [InlineKeyboardButton("🗳️ Создать голосование", callback_data="/create_poll")],
            [InlineKeyboardButton("📋 Мои группы", callback_data="/my_groups")],
            [InlineKeyboardButton("🗑️ Удалить пост", callback_data="/deletepost")],
            [InlineKeyboardButton("❓ Помощь", callback_data="/help")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def groups_list(groups, action_prefix):
        """Список групп"""
        keyboard = []
        for group_id, group_title in groups:
            display_title = group_title[:30] + "..." if len(group_title) > 30 else group_title
            keyboard.append([
                InlineKeyboardButton(
                    f"📌 {display_title}",
                    callback_data=f"{action_prefix}_{group_id}"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("« Назад", callback_data="back_to_main")])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def post_type_selection():
        """Выбор типа поста"""
        keyboard = [
            [InlineKeyboardButton("✏️ Текстовый пост (можно с медиа)", callback_data="post_type_text")],
            [InlineKeyboardButton("📨 Переслать сообщение", callback_data="post_type_forward")],
            [InlineKeyboardButton("💬 Ответить на сообщение (можно с медиа)", callback_data="post_type_reply")],
            [InlineKeyboardButton("« Назад", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def poll_type_selection():
        """Выбор типа голосования"""
        keyboard = [
            [InlineKeyboardButton("📊 Обычное голосование (1 вариант)", callback_data="poll_type_regular")],
            [InlineKeyboardButton("📋 Множественный выбор", callback_data="poll_type_multiple")],
            [InlineKeyboardButton("🎓 Викторина (правильный ответ)", callback_data="poll_type_quiz")],
            [InlineKeyboardButton("🙈 Анонимное голосование", callback_data="poll_type_anonymous")],
            [InlineKeyboardButton("« Назад", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def button_options():
        """Выбор добавления кнопок"""
        keyboard = [
            [InlineKeyboardButton("✅ Да, добавить кнопки", callback_data="button_yes")],
            [InlineKeyboardButton("❌ Нет, без кнопок", callback_data="button_no")],
            [InlineKeyboardButton("« Назад", callback_data="back_to_post_type")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def mention_options():
        """Выбор упоминаний"""
        keyboard = [
            [InlineKeyboardButton("👥 Упомянуть всех участников", callback_data="mention_all")],
            [InlineKeyboardButton("🎭 Упомянуть по роли", callback_data="mention_role")],
            [InlineKeyboardButton("❌ Без упоминаний", callback_data="mention_none")],
            [InlineKeyboardButton("« Назад", callback_data="back_to_button_selection")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def role_selection():
        """Выбор роли для упоминания"""
        roles = RolesManager.get_role_names()
        keyboard = []
        
        for role_name in roles:
            usernames = RolesManager.get_usernames_by_role(role_name)
            count = len(usernames)
            
            display_name = role_name[:25] + "..." if len(role_name) > 25 else role_name
            
            keyboard.append([
                InlineKeyboardButton(
                    f"🎭 {display_name} ({count})",
                    callback_data=f"role_{role_name}"
                )
            ])
        
        if not keyboard:
            keyboard.append([
                InlineKeyboardButton(
                    "📝 Добавьте роли в файл roles.txt",
                    callback_data="no_roles"
                )
            ])
        
        keyboard.append([InlineKeyboardButton("« Назад", callback_data="back_to_mention_options")])
        
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def confirm_delete():
        """Подтверждение удаления"""
        keyboard = [
            [
                InlineKeyboardButton("✅ Удалить", callback_data="confirm_delete"),
                InlineKeyboardButton("❌ Отменить", callback_data="cancel_delete")
            ],
            [InlineKeyboardButton("« Назад", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def back_button(callback_data="back_to_main"):
        """Кнопка назад"""
        keyboard = [[InlineKeyboardButton("« Назад", callback_data=callback_data)]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def cancel_button():
        """Кнопка отмены"""
        keyboard = [[InlineKeyboardButton("❌ Отмена", callback_data="cancel_post")]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def cancel_poll_button():
        """Кнопка отмены голосования"""
        keyboard = [[InlineKeyboardButton("❌ Отмена", callback_data="cancel_poll")]]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def create_post_button(group_id):
        """Кнопка создания поста для группы"""
        keyboard = [
            [InlineKeyboardButton("📝 Создать пост", callback_data=f"create_post_{group_id}")],
            [InlineKeyboardButton("« Назад", callback_data="/my_groups")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def confirm_send():
        """Подтверждение отправки"""
        keyboard = [
            [
                InlineKeyboardButton("✅ Отправить", callback_data="confirm_send"),
                InlineKeyboardButton("✏️ Редактировать", callback_data="edit_post")
            ],
            [InlineKeyboardButton("« Назад", callback_data="back_to_main")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def select_correct_option(options_count):
        """Выбор правильного ответа для викторины"""
        keyboard = []
        for i in range(options_count):
            keyboard.append([
                InlineKeyboardButton(f"✅ Вариант {i+1}", callback_data=f"correct_option_{i}")
            ])
        keyboard.append([InlineKeyboardButton("« Назад", callback_data="back_to_poll_options")])
        return InlineKeyboardMarkup(keyboard)
    
    @staticmethod
    def poll_back_button():
        """Кнопка назад для голосования"""
        keyboard = [[InlineKeyboardButton("« Назад", callback_data="back_to_poll_type")]]
        return InlineKeyboardMarkup(keyboard)