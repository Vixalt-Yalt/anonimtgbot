import re
import asyncio
import html
from telegram.constants import ChatMemberStatus, ParseMode
from telegram.error import BadRequest, NetworkError
from config import Config
import logging

logger = logging.getLogger(__name__)

class Utils:

    @staticmethod
    def parse_message_entities(text, entities):
        """
        Конвертирует сообщение с entities в HTML разметку Telegram
        Правильно обрабатывает несколько Premium эмодзи
        """
        if not text or not entities:
            return text
        
        sorted_entities = sorted(entities, key=lambda e: e.offset, reverse=True)
        result = text
        
        for entity in sorted_entities:
            offset = entity.offset
            length = entity.length
            
            original_text = result[offset:offset+length]
            
            if entity.type == "custom_emoji":
                custom_emoji_id = entity.custom_emoji_id
                replacement = f'<tg-emoji emoji-id="{custom_emoji_id}">{original_text}</tg-emoji>'
                logger.debug(f"✨ Premium эмодзи, ID: {custom_emoji_id}")
            
            elif entity.type == "bold":
                replacement = f"<b>{original_text}</b>"
            elif entity.type == "italic":
                replacement = f"<i>{original_text}</i>"
            elif entity.type == "underline":
                replacement = f"<u>{original_text}</u>"
            elif entity.type == "strikethrough":
                replacement = f"<s>{original_text}</s>"
            elif entity.type == "spoiler":
                replacement = f"<tg-spoiler>{original_text}</tg-spoiler>"
            elif entity.type == "code":
                replacement = f"<code>{original_text}</code>"
            elif entity.type == "pre":
                language = entity.language if hasattr(entity, 'language') and entity.language else ""
                if language:
                    replacement = f'<pre><code class="language-{language}">{original_text}</code></pre>'
                else:
                    replacement = f"<pre>{original_text}</pre>"
            elif entity.type == "text_link":
                url = entity.url
                replacement = f'<a href="{url}">{original_text}</a>'
            elif entity.type == "text_mention":
                user = entity.user
                if user.username:
                    replacement = f'<a href="https://t.me/{user.username}">{original_text}</a>'
                else:
                    user_id = user.id
                    replacement = f'<a href="tg://user?id={user_id}">{original_text}</a>'
            else:
                continue
            
            result = result[:offset] + replacement + result[offset + length:]
        
        return result
    
    @staticmethod
    def extract_full_formatting(message):
        """Извлекает ВСЕ форматирование из сообщения"""
        if not message:
            return ""
        
        text = message.text or message.caption or ""
        
        entities = None
        if message.entities:
            entities = message.entities
        elif message.caption_entities:
            entities = message.caption_entities
        
        if entities:
            return Utils.parse_message_entities(text, entities)
        else:
            return html.escape(text)
    
    @staticmethod
    async def copy_message_with_full_formatting(bot, chat_id, from_chat_id, message_id, 
                                                caption=None, reply_markup=None, 
                                                message_thread_id=None):
        """Копирует сообщение с ПОЛНЫМ сохранением форматирования"""
        try:
            params = {
                'chat_id': chat_id,
                'from_chat_id': from_chat_id,
                'message_id': message_id,
                'disable_notification': True
            }
            
            if caption:
                params['caption'] = caption
                params['parse_mode'] = ParseMode.HTML
            
            if message_thread_id:
                params['message_thread_id'] = message_thread_id
            
            if reply_markup:
                params['reply_markup'] = reply_markup
            
            result = await bot.copy_message(**params)
            logger.info(f"✅ Сообщение скопировано с полным форматированием, ID: {result.message_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Ошибка копирования сообщения: {e}")
            raise
    
    @staticmethod
    async def send_sticker_preserve_format(bot, chat_id, sticker_file_id, 
                                          message_thread_id=None, reply_markup=None):
        """Отправляет стикер с сохранением всех свойств"""
        try:
            params = {
                'chat_id': chat_id,
                'sticker': sticker_file_id,
                'disable_notification': True
            }
            
            if message_thread_id:
                params['message_thread_id'] = message_thread_id
            
            if reply_markup:
                params['reply_markup'] = reply_markup
            
            result = await bot.send_sticker(**params)
            logger.info(f"✅ Стикер отправлен, ID: {result.message_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Ошибка отправки стикера: {e}")
            raise
    
    @staticmethod
    async def send_message_with_full_formatting(bot, chat_id, text, 
                                                entities=None, reply_markup=None,
                                                message_thread_id=None,
                                                disable_web_page_preview=True):
        """Отправляет сообщение с ПОЛНЫМ сохранением форматирования"""
        try:
            if entities:
                html_text = Utils.parse_message_entities(text, entities)
                params = {
                    'chat_id': chat_id,
                    'text': html_text,
                    'parse_mode': ParseMode.HTML,
                    'disable_web_page_preview': disable_web_page_preview,
                    'disable_notification': True
                }
            else:
                html_text = Utils.parse_markdown_to_html(text)
                params = {
                    'chat_id': chat_id,
                    'text': html_text,
                    'parse_mode': ParseMode.HTML,
                    'disable_web_page_preview': disable_web_page_preview,
                    'disable_notification': True
                }
            
            if message_thread_id:
                params['message_thread_id'] = message_thread_id
            
            if reply_markup:
                params['reply_markup'] = reply_markup
            
            try:
                result = await bot.send_message(**params)
                logger.info(f"✅ Сообщение отправлено с HTML форматированием")
                return result
            except BadRequest as e:
                if "can't parse entities" in str(e).lower():
                    params['parse_mode'] = None
                    result = await bot.send_message(**params)
                    logger.info("✅ Сообщение отправлено без форматирования")
                    return result
                else:
                    raise
                    
        except Exception as e:
            logger.error(f"❌ Ошибка отправки сообщения: {e}")
            raise
    
    @staticmethod
    def parse_markdown_to_html(text):
        """Преобразует Markdown в HTML разметку Telegram"""
        if not text:
            return ""
        
        text = html.escape(text)
        text = text.replace('&amp;amp;', '&amp;')
        
        text = re.sub(r'\|\|(.*?)\|\|', r'<tg-spoiler>\1</tg-spoiler>', text)
        
        def replace_link(match):
            link_text = match.group(1)
            link_url = match.group(2)
            if not link_url.startswith(('http://', 'https://', 'tg://')):
                link_url = 'https://' + link_url
            return f'<a href="{link_url}">{link_text}</a>'
        
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', replace_link, text)
        
        text = re.sub(r'\*\*\*(.*?)\*\*\*', r'<b><i>\1</i></b>', text)
        text = re.sub(r'___(.*?)___', r'<b><i>\1</i></b>', text)
        
        text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
        text = re.sub(r'__(.*?)__', r'<b>\1</b>', text)
        
        text = re.sub(r'\*([^*]+)\*', r'<i>\1</i>', text)
        text = re.sub(r'_([^_]+)_', r'<i>\1</i>', text)
        
        text = re.sub(r'\+\+(.*?)\+\+', r'<u>\1</u>', text)
        
        text = re.sub(r'~~(.*?)~~', r'<s>\1</s>', text)
        
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
        
        def replace_code_block(match):
            code = match.group(1)
            code = code.strip()
            code = html.escape(code)
            return f'<pre>{code}</pre>'
        
        text = re.sub(r'```(.*?)```', replace_code_block, text, flags=re.DOTALL)
        
        def replace_direct_url(match):
            url = match.group(1)
            url = url.rstrip('.,!?;:')
            return f'<a href="{url}">{url}</a>'
        
        url_pattern = r'(?<!["\'])(https?://[^\s<>]+[^\s<>\.])'
        text = re.sub(url_pattern, replace_direct_url, text)
        
        text = text.strip()
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        return text
    
    @staticmethod
    def parse_topic_link(link):
        """Парсинг ссылки на тему - возвращает topic_id или None для основного чата"""
        link = link.strip()
        
        if link.lower() in ['нет', 'no', 'skip', 'пропустить', 'основная', 'main', '0', 'основной', '']:
            return None
        
        logger.info(f"Парсим ссылку на тему: {link}")
        
        match = re.search(r'c/(\d+)/(\d+)$', link)
        if match:
            topic_id = int(match.group(2))
            logger.info(f"Найден topic_id: {topic_id}")
            return topic_id
        
        match = re.search(r't\.me/c/(\d+)/(\d+)$', link, re.IGNORECASE)
        if match:
            topic_id = int(match.group(2))
            logger.info(f"Найден topic_id: {topic_id}")
            return topic_id
        
        if re.match(r'^\d+$', link):
            topic_id = int(link)
            logger.info(f"Найден topic_id: {topic_id}")
            return topic_id
        
        match = re.search(r'/(\d+)$', link)
        if match:
            topic_id = int(match.group(1))
            logger.info(f"Найден topic_id: {topic_id}")
            return topic_id
        
        logger.warning(f"Не удалось распарсить ссылку на тему: {link}")
        return None
    
    @staticmethod
    def parse_message_link(link):
        """Парсинг ссылки на сообщение - возвращает информацию о ссылке"""
        link = link.strip()
        logger.info(f"Парсим ссылку на сообщение: {link}")
        
        match = re.search(r'c/(\d+)/(\d+)/(\d+)$', link)
        if match:
            chat_id = int(match.group(1))
            topic_id = int(match.group(2))
            message_id = int(match.group(3))
            logger.info(f"Найдена ссылка на приватную группу с темой: chat_id={chat_id}, topic_id={topic_id}, message_id={message_id}")
            return {
                'type': 'private_chat_with_topic', 
                'chat_id': chat_id,
                'topic_id': topic_id, 
                'message_id': message_id,
                'is_private_group': True
            }
        
        match = re.search(r'c/(\d+)/(\d+)$', link)
        if match:
            chat_id = int(match.group(1))
            message_id = int(match.group(2))
            logger.info(f"Найдена ссылка на приватную группу без темы: chat_id={chat_id}, message_id={message_id}")
            return {
                'type': 'private_chat', 
                'chat_id': chat_id,
                'message_id': message_id,
                'is_private_group': True
            }
        
        match = re.search(r't\.me/([^/]+)/(\d+)$', link)
        if match:
            chat_username = match.group(1)
            message_id = int(match.group(2))
            logger.info(f"Найдена ссылка на публичный чат: username={chat_username}, message_id={message_id}")
            
            if chat_username.startswith('c/'):
                return None
            
            return {
                'type': 'public', 
                'chat_username': chat_username, 
                'message_id': message_id
            }
        
        match = re.search(r't\.me/([^/\s]+)$', link)
        if match:
            chat_username = match.group(1)
            logger.info(f"Найдена ссылка только на чат: username={chat_username}")
            return {'type': 'channel_only', 'chat_username': chat_username}
        
        logger.warning(f"Не удалось распарсить ссылку: {link}")
        return None
    
    @staticmethod
    def convert_to_telegram_chat_id(chat_id):
        """Конвертирует chat_id в формат Telegram"""
        try:
            if chat_id < 0:
                return chat_id
            
            if chat_id > 0:
                formats_to_try = []
                formats_to_try.append(chat_id)
                formats_to_try.append(-chat_id)
                
                if chat_id > 1000000000:
                    last_digits = str(chat_id)[3:]
                    if last_digits:
                        formats_to_try.append(-int(f"100{last_digits}"))
                
                logger.info(f"Возможные форматы chat_id для {chat_id}: {formats_to_try}")
                return formats_to_try[0]
                
        except Exception as e:
            logger.error(f"Ошибка конвертации chat_id {chat_id}: {e}")
            return chat_id
    
    @staticmethod
    def get_possible_chat_ids(chat_id):
        """Возвращает список возможных chat_id для отправки"""
        if not chat_id:
            return []
        
        possible_ids = []
        possible_ids.append(chat_id)
        possible_ids.append(-chat_id)
        
        converted = Utils.convert_to_telegram_chat_id(chat_id)
        if converted != chat_id:
            possible_ids.append(converted)
        
        if chat_id > 1000000000:
            try:
                last_digits = str(chat_id)[3:]
                if last_digits:
                    possible_ids.append(-int(f"100{last_digits}"))
            except:
                pass
        
        unique_ids = []
        for pid in possible_ids:
            if pid not in unique_ids:
                unique_ids.append(pid)
        
        logger.info(f"Возможные chat_id для {chat_id}: {unique_ids}")
        return unique_ids
    
    @staticmethod
    async def get_all_members(bot, chat_id):
        """Получаем ВСЕХ участников группы (админов + простых)"""
        members = []
        try:
            admins = await asyncio.wait_for(
                bot.get_chat_administrators(chat_id),
                timeout=30
            )
            for admin in admins:
                if not admin.user.is_bot:
                    members.append({
                        'id': admin.user.id,
                        'username': admin.user.username,
                        'first_name': admin.user.first_name,
                        'last_name': admin.user.last_name,
                        'role': 'admin'
                    })
            
            logger.info(f"Найдено {len(members)} администраторов для чата {chat_id}")
            return members
            
        except asyncio.TimeoutError:
            logger.warning(f"Таймаут получения участников для чата {chat_id}")
            return []
        except Exception as e:
            logger.error(f"Ошибка получения участников для чата {chat_id}: {e}")
            return []
    
    @staticmethod
    def format_mentions(members):
        """Форматирование упоминаний @username1, @username2"""
        if not members:
            return ""
        
        mentions = []
        for member in members:
            username = member.get('username')
            if username:
                mentions.append(f"@{username}")
        
        if not mentions:
            return ""
        
        return ", ".join(mentions) + "\n\n"
    
    @staticmethod
    def validate_post(text):
        """Проверка поста на валидность"""
        if not text or len(text.strip()) == 0:
            return False, "Сообщение не может быть пустым"
        
        clean_text = re.sub('<[^<]+?>', '', text)
        clean_text = html.unescape(clean_text)
        
        if len(clean_text) > Config.MAX_POST_LENGTH:
            return False, f"Сообщение слишком длинное (макс. {Config.MAX_POST_LENGTH} символов)"
        
        return True, ""
    
    @staticmethod
    def escape_html(text):
        """Экранирует HTML символы"""
        if not text:
            return ""
        
        text = text.replace('&', '&amp;')
        text = text.replace('<', '&lt;')
        text = text.replace('>', '&gt;')
        text = text.replace('"', '&quot;')
        text = text.replace("'", '&#39;')
        
        return text
    
    @staticmethod
    def extract_mentions(text):
        """Извлекает упоминания из текста"""
        if not text:
            return []
        
        mentions = re.findall(r'@(\w+)', text)
        return mentions
    
    @staticmethod
    def remove_mentions(text):
        """Убирает упоминания из текста"""
        if not text:
            return ""
        
        text = re.sub(r'@\w+\s*', '', text)
        
        lines = text.split('\n')
        lines = [line.strip() for line in lines if line.strip()]
        
        return '\n'.join(lines)