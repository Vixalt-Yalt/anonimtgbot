import sys
import os
import logging
import asyncio
import socket
import time

import warnings
warnings.filterwarnings("ignore", message="cannot create weak reference")

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('anonim.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)

try:
    from telegram import Update, Bot
    from telegram.ext import (
        Application, CommandHandler, CallbackQueryHandler,
        MessageHandler, filters, ContextTypes, ConversationHandler
    )
    from telegram.constants import ParseMode, ChatType
    from telegram.error import BadRequest, TelegramError, NetworkError
except Exception as e:
    print(f"❌ Ошибка импорта библиотек: {e}")
    print("Установите библиотеки командой:")
    print("pip install python-telegram-bot python-dotenv")
    sys.exit(1)

from config import Config
from handlers import Handlers
from states import States
from keyboards import Keyboards

class SingleInstance:
    """Класс для обеспечения запуска только одного экземпляра бота"""
    
    def __init__(self, port=12345):
        self.port = port
        self.socket = None
    
    def lock(self):
        """Пытаемся захватить порт для блокировки"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.bind(('localhost', self.port))
            self.socket.listen(5)
            return True
        except socket.error:
            return False
    
    def unlock(self):
        """Освобождаем порт"""
        if self.socket:
            try:
                self.socket.close()
            except:
                pass

class AnonimBot:
    def __init__(self):
        logger.info("Инициализация бота...")
        
        self.instance_lock = SingleInstance()
        if not self.instance_lock.lock():
            print("❌ Ошибка: Бот уже запущен!")
            print("   Завершите другие экземпляры бота командой:")
            print("   taskkill /f /im python.exe")
            sys.exit(1)
        
        try:
            self.application = Application.builder().token(Config.BOT_TOKEN).build()
            logger.info("Application создан успешно")
        except Exception as e:
            logger.error(f"Ошибка создания Application: {e}")
            print(f"❌ Ошибка инициализации бота: {e}")
            print("Попробуйте установить другую версию библиотеки:")
            print("pip install python-telegram-bot==20.3")
            sys.exit(1)
        
        self.application.add_error_handler(self.error_handler)
        
        self.setup_handlers()
    
    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик ошибок"""
        try:
            if context.error:
                logger.error(f'Ошибка: {context.error}', exc_info=context.error)
                
                if isinstance(context.error, asyncio.TimeoutError):
                    if update and hasattr(update, 'effective_chat') and update.effective_chat:
                        try:
                            await context.bot.send_message(
                                chat_id=update.effective_chat.id,
                                text="⏱️ Превышено время ожидания. Попробуйте снова."
                            )
                        except:
                            pass
                elif "Query is too old" in str(context.error):
                    return ConversationHandler.END
        except Exception as e:
            logger.error(f'Ошибка в обработчике ошибок: {e}')
        
        return ConversationHandler.END
    
    def setup_handlers(self):
        """Настройка обработчиков команд и сообщений"""
        logger.info("Настраиваю обработчики...")
        
        auth_conv_handler = ConversationHandler(
            entry_points=[CommandHandler("start", Handlers.start_command)],
            states={
                States.WAITING_FOR_PASSWORD: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.check_password),
                    CommandHandler("cancel", Handlers.cancel_auth),
                ]
            },
            fallbacks=[
                CommandHandler("cancel", Handlers.cancel_auth),
            ],
            name="auth_conversation",
            per_user=True,
            per_chat=True,
            per_message=False
        )
        
        post_conv_handler = ConversationHandler(
            entry_points=[
                CommandHandler("create_post", Handlers.create_post_command),
                CallbackQueryHandler(Handlers.create_post_command, pattern='^/create_post$')
            ],
            states={
                States.SELECTING_GROUP: [
                    CallbackQueryHandler(Handlers.select_group_for_post, pattern='^select_group_post_'),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_POST_TYPE: [
                    CallbackQueryHandler(Handlers.select_post_type, pattern='^post_type_'),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_BUTTON_OPTION: [
                    CallbackQueryHandler(Handlers.select_button_option, pattern='^button_'),
                    CallbackQueryHandler(Handlers.go_back_to_post_type, pattern='^back_to_post_type$'),
                ],
                States.ADDING_BUTTONS: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_buttons_input),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_MENTION_OPTION: [
                    CallbackQueryHandler(Handlers.select_mention_option, pattern='^mention_'),
                    CallbackQueryHandler(Handlers.go_back_to_button_selection, pattern='^back_to_button_selection$'),
                ],
                States.SELECTING_ROLE: [
                    CallbackQueryHandler(Handlers.select_role_for_mention, pattern='^role_|no_roles$'),
                    CallbackQueryHandler(Handlers.go_back_to_mention_options, pattern='^back_to_mention_options$'),
                ],
                States.WRITING_POST: [
                    MessageHandler(
                        filters.TEXT | 
                        filters.PHOTO | 
                        filters.VIDEO | 
                        filters.Document.ALL | 
                        filters.AUDIO | 
                        filters.VOICE | 
                        filters.ANIMATION |
                        filters.Sticker.ALL |
                        filters.FORWARDED,
                        Handlers.receive_post_content
                    ),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.REPLY_MESSAGE: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_message_link),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.REPLY_TEXT: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_reply_text),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_TOPIC: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_topic_input),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
            },
            fallbacks=[
                CommandHandler("cancel", Handlers.cancel_auth),
                CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                CallbackQueryHandler(Handlers.cancel_post, pattern='^cancel_post$'),
            ],
            name="post_conversation",
            per_user=True,
            per_chat=True,
            per_message=False,
            allow_reentry=True
        )
        
        poll_conv_handler = ConversationHandler(
            entry_points=[
                CommandHandler("create_poll", Handlers.create_poll_command),
                CallbackQueryHandler(Handlers.create_poll_command, pattern='^/create_poll$')
            ],
            states={
                States.SELECTING_GROUP: [
                    CallbackQueryHandler(Handlers.select_group_for_poll, pattern='^select_group_poll_'),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.WRITING_POLL_QUESTION: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_poll_question),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.WRITING_POLL_OPTIONS: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_poll_options),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_POLL_TYPE: [
                    CallbackQueryHandler(Handlers.select_poll_type, pattern='^poll_type_'),
                    CallbackQueryHandler(Handlers.go_back_to_poll_type, pattern='^back_to_poll_type$'),
                ],
                States.WRITING_QUIZ_CORRECT_ANSWER: [
                    CallbackQueryHandler(Handlers.select_correct_option, pattern='^correct_option_'),
                    CallbackQueryHandler(Handlers.go_back_to_poll_options, pattern='^back_to_poll_options$'),
                ],
                States.WRITING_QUIZ_EXPLANATION: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_quiz_explanation),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.SELECTING_POLL_TOPIC: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_poll_topic),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
            },
            fallbacks=[
                CommandHandler("cancel", Handlers.cancel_auth),
                CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                CallbackQueryHandler(Handlers.cancel_poll, pattern='^cancel_poll$'),
            ],
            name="poll_conversation",
            per_user=True,
            per_chat=True,
            per_message=False,
            allow_reentry=True
        )
        
        delete_conv_handler = ConversationHandler(
            entry_points=[
                CommandHandler("deletepost", Handlers.delete_post_command),
                CallbackQueryHandler(Handlers.delete_post_command, pattern='^/deletepost$')
            ],
            states={
                States.DELETE_POST: [
                    MessageHandler(filters.TEXT & ~filters.COMMAND, Handlers.receive_delete_link),
                    CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$'),
                ],
                States.CONFIRM_DELETE: [
                    CallbackQueryHandler(Handlers.confirm_delete_action, pattern='^(confirm_delete|cancel_delete)$'),
                ]
            },
            fallbacks=[
                CommandHandler("cancel", Handlers.cancel_auth),
                CallbackQueryHandler(Handlers.go_back_to_main, pattern='^back_to_main$')
            ],
            name="delete_conversation",
            per_user=True,
            per_chat=True,
            per_message=False
        )
        
        self.application.add_handler(CommandHandler("help", Handlers.help_command))
        
        self.application.add_handler(CommandHandler("bind_group", Handlers.bind_group_command))
        self.application.add_handler(CommandHandler("my_groups", Handlers.my_groups_command))
        
        self.application.add_handler(auth_conv_handler)
        self.application.add_handler(post_conv_handler)
        self.application.add_handler(poll_conv_handler)
        self.application.add_handler(delete_conv_handler)
        
        self.application.add_handler(CallbackQueryHandler(Handlers.handle_callback_query))
        
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_text_commands))
        
        self.application.add_handler(MessageHandler(filters.TEXT & (filters.ChatType.GROUPS | filters.ChatType.SUPERGROUP), Handlers.handle_group_command))
        
        self.application.add_handler(MessageHandler(filters.ChatType.GROUPS | filters.ChatType.SUPERGROUP, Handlers.ignore_group_message))
        
        logger.info("Обработчики настроены")
    
    async def handle_text_commands(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик текстовых команд (только help)"""
        if not update.message or not update.message.text:
            return
        
        text = update.message.text.strip().lower()
        
        if text == 'help':
            return await Handlers.help_command(update, context)
        
        return
    
    def run(self):
        """Запуск бота"""
        print(f"🚀 Анонимный Бот запущен!")
        print(f"📊 База данных: {Config.DB_NAME}")
        print("⚡ Бот готов к работе! Нажмите Ctrl+C для остановки")
        print("📝 Логи записываются в файл: anonim.log")
        print("🔒 Проверка: только один экземпляр бота может быть запущен")
        
        logger.info(f"Бот запущен. База данных: {Config.DB_NAME}")
        logger.info("Бот готов к работе")
        
        try:
            self.application.run_polling(
                allowed_updates=['message', 'callback_query'],
                drop_pending_updates=True,
                close_loop=False
            )
        except KeyboardInterrupt:
            logger.info("Бот остановлен пользователем")
            print("\n🛑 Бот остановлен.")
        except Exception as e:
            logger.critical(f"Критическая ошибка: {e}", exc_info=True)
            print(f"❌ Критическая ошибка: {e}")
        finally:
            self.instance_lock.unlock()

def main():
    bot = AnonimBot()
    bot.run()

if __name__ == '__main__':
    main()