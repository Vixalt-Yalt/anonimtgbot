import sqlite3
from datetime import datetime
from config import Config
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self):
        self.conn = sqlite3.connect(Config.DB_NAME, check_same_thread=False)
        self.create_tables()
    
    def create_tables(self):
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER UNIQUE,
                group_title TEXT,
                bound_by INTEGER,
                bound_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                authorized INTEGER DEFAULT 0,
                authorized_date TIMESTAMP,
                joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tag_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                user_id INTEGER,
                tag_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS roles_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                user_id INTEGER,
                role TEXT,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(group_id, user_id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS post_buttons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                button_data TEXT,
                created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        try:
            cursor.execute("DROP TABLE IF EXISTS post_buttons_old")
        except:
            pass
        
        self.conn.commit()
        logger.info("Таблицы базы данных созданы/обновлены")
    
    def bind_group(self, group_id, group_title, user_id):
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO groups (group_id, group_title, bound_by)
                VALUES (?, ?, ?)
            ''', (group_id, group_title, user_id))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"Database error in bind_group: {e}")
            return False
    
    def get_user_groups(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT group_id, group_title FROM groups 
            WHERE bound_by = ?
            ORDER BY group_title
        ''', (user_id,))
        return cursor.fetchall()
    
    def get_group_info(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT group_id, group_title FROM groups 
            WHERE group_id = ?
        ''', (group_id,))
        return cursor.fetchone()
    
    def save_user(self, user_id, username, first_name, last_name):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT OR IGNORE INTO users (user_id, username, first_name, last_name)
            VALUES (?, ?, ?, ?)
        ''', (user_id, username, first_name, last_name))
        self.conn.commit()
    
    def is_user_authorized(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT authorized FROM users WHERE user_id = ?
        ''', (user_id,))
        result = cursor.fetchone()
        return result and result[0] == 1
    
    def authorize_user(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            UPDATE users 
            SET authorized = 1, authorized_date = CURRENT_TIMESTAMP
            WHERE user_id = ?
        ''', (user_id,))
        self.conn.commit()
        return cursor.rowcount > 0
    
    def log_tag(self, group_id, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO tag_logs (group_id, user_id) VALUES (?, ?)
        ''', (group_id, user_id))
        self.conn.commit()
    
    def get_last_tag_time(self, group_id, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT tag_date FROM tag_logs 
            WHERE group_id = ? AND user_id = ?
            ORDER BY tag_date DESC LIMIT 1
        ''', (group_id, user_id))
        result = cursor.fetchone()
        return result[0] if result else None
    
    def save_role(self, group_id, user_id, role, username, first_name, last_name):
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO roles_cache 
            (group_id, user_id, role, username, first_name, last_name)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (group_id, user_id, role, username, first_name, last_name))
        self.conn.commit()
    
    def get_users_by_role(self, group_id, role):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT user_id, username, first_name, last_name 
            FROM roles_cache 
            WHERE group_id = ? AND role = ?
        ''', (group_id, role))
        return cursor.fetchall()
    
    def clear_roles_cache(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM roles_cache WHERE group_id = ?', (group_id,))
        self.conn.commit()

    def save_post_buttons(self, user_id, button_data):
        cursor = self.conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO post_buttons (user_id, button_data)
                VALUES (?, ?)
            ''', (user_id, button_data))
            self.conn.commit()
            return cursor.lastrowid
        except Exception as e:
            logger.error(f"Ошибка сохранения кнопок: {e}")
            try:
                cursor.execute('DROP TABLE IF EXISTS post_buttons')
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS post_buttons (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        button_data TEXT,
                        created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                self.conn.commit()
                cursor.execute('''
                    INSERT INTO post_buttons (user_id, button_data)
                    VALUES (?, ?)
                ''', (user_id, button_data))
                self.conn.commit()
                return cursor.lastrowid
            except Exception as e2:
                logger.error(f"Ошибка пересоздания таблицы кнопок: {e2}")
                return None
    
    def get_post_buttons(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT button_data FROM post_buttons 
            WHERE user_id = ? 
            ORDER BY created_date DESC LIMIT 1
        ''', (user_id,))
        result = cursor.fetchone()
        return result[0] if result else None
    
    def clear_post_buttons(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM post_buttons WHERE user_id = ?', (user_id,))
        self.conn.commit()
    
    def close(self):
        self.conn.close()