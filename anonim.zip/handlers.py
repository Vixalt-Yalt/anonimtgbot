import logging
import re
import asyncio
import html
import os
import ast
from telegram import Update, ChatMember, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from telegram.constants import ParseMode, ChatType
from telegram.error import BadRequest, TelegramError, NetworkError

from config import Config
from database import Database
from keyboards import Keyboards
from states import States
from roles_manager import RolesManager
from utils import Utils

logger = logging.getLogger(__name__)
db = Database()

class Handlers:
    
    @staticmethod
    async def ignore_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Игнорировать сообщения в группах, если это не команда"""
        return ConversationHandler.END
    
    
    @staticmethod
    async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Команда /help или help - справка по боту"""
        user = update.effective_user
        is_authorized = context.user_data.get('authorized', False) or db.is_user_authorized(user.id)
        
        if not is_authorized:
            await update.message.reply_text(
                "🤖 <b>Аноним Бот</b>\n\n"
                "Я бот для анонимных постов в группах.\n\n"
                "<b>Доступные команды:</b>\n"
                "• /help - показать это сообщение\n"
                "• /start - начать работу (ввести пароль)\n\n"
                "<b>Для работы с ботом необходимо:</b>\n"
                "1. Ввести пароль через /start\n"
                "2. Добавить бота в группу как администратора\n"
                "3. В группе написать /bind_group для привязки",
                parse_mode=ParseMode.HTML
            )
        else:
            roles = RolesManager.get_role_names()
            roles_text = "\n".join([f"• {role} ({len(RolesManager.get_usernames_by_role(role))} чел.)" 
                                  for role in roles]) if roles else "• Роли не настроены"
            
            await update.message.reply_text(
                "📚 <b>Справка по боту:</b>\n\n"
                "<b>Основные команды:</b>\n"
                "• /create_post - создать пост\n"
                "• /create_poll - создать голосование\n"
                "• /deletepost - удалить сообщение\n"
                "• /my_groups - мои группы\n"
                "• /bind_group - привязать группу (в группе)\n\n"
                "<b>🎯 Типы постов:</b>\n"
                "• 📝 Текстовый пост (можно с медиа)\n"
                "• 📨 Переслать сообщение\n"
                "• 💬 Ответить на сообщение\n\n"
                "<b>🗳️ Типы голосований:</b>\n"
                "• Обычное голосование\n"
                "• Множественный выбор\n"
                "• Викторина\n"
                "• Анонимное голосование\n\n"
                "<b>👥 Упоминания:</b>\n"
                "• Упомянуть всех участников\n"
                "• Упомянуть по ролям (из roles.txt)\n"
                "• Без упоминаний\n\n"
                f"<b>🎭 Доступные роли ({len(roles)}):</b>\n{roles_text}\n\n"
                "⚠️ <b>Бот должен быть администратором в группе!</b>",
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
                reply_markup=Keyboards.back_button()
            )
        return ConversationHandler.END
    
    
    @staticmethod
    async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Команда /start - начало авторизации"""
        user = update.effective_user
        
        db.save_user(user.id, user.username, user.first_name, user.last_name)
        
        logger.info(f"Пользователь {user.id} ({user.username}) начал авторизацию")
        
        await update.message.reply_text(
            "🔒 <b>Вход в систему</b>\n\n"
            "Для доступа к боту введите пароль:",
            parse_mode=ParseMode.HTML
        )
        return States.WAITING_FOR_PASSWORD
    
    @staticmethod
    async def check_password(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Проверка пароля"""
        user = update.effective_user
        password_attempt = update.message.text.strip()
        
        if password_attempt == Config.BOT_PASSWORD:
            context.user_data['authorized'] = True
            db.authorize_user(user.id)
            
            logger.info(f"Пользователь {user.id} ({user.username}) успешно авторизовался")
            
            await update.message.reply_text(
                "✅ <b>Пароль верный!</b>\n\n"
                "👋 <b>Аноним Бот</b> - быстрый бот для анонимных постов!\n\n"
                "⚡ <b>Используйте меню:</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
            return ConversationHandler.END
        else:
            logger.warning(f"Пользователь {user.id} ({user.username}) ввел неверный пароль: {password_attempt}")
            await update.message.reply_text(
                "❌ <b>Неверный пароль!</b>\n\n"
                "Попробуйте еще раз или /cancel",
                parse_mode=ParseMode.HTML
            )
            return States.WAITING_FOR_PASSWORD
    
    @staticmethod
    async def require_auth(update: Update, context: ContextTypes.DEFAULT_TYPE, message=None):
        """Требует авторизации"""
        if update.callback_query:
            await update.callback_query.answer("🔒 Требуется авторизация! Используйте /start", show_alert=True)
        elif message:
            await message.reply_text(
                "🔒 <b>Требуется авторизация!</b>\n\n"
                "Используйте /start для ввода пароля.",
                parse_mode=ParseMode.HTML
            )
        return ConversationHandler.END
    
    @staticmethod
    async def cancel_auth(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отмена авторизации"""
        user = update.effective_user
        logger.info(f"Пользователь {user.id} ({user.username}) отменил авторизацию")
        
        await update.message.reply_text(
            "❌ Авторизация отменена.\n\n"
            "Используйте /start для повторной попытки.",
            parse_mode=ParseMode.HTML
        )
        return ConversationHandler.END
    
    
    @staticmethod
    async def bind_group_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Привязка группы"""
        user = update.effective_user
        message = update.message
        chat = message.chat
        
        logger.info(f"Пользователь {user.id} пытается привязать группу {chat.title} ({chat.id})")
        
        if update.effective_chat.type == ChatType.PRIVATE:
            if not context.user_data.get('authorized'):
                return await Handlers.require_auth(update, context, update.message)
        
        if chat.type not in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if chat.type == ChatType.PRIVATE:
                await message.reply_text(
                    "❌ <b>Неверное место использования!</b>\n\n"
                    "Команду /bind_group нужно использовать в группе, которую вы хотите привязать.",
                    parse_mode=ParseMode.HTML
                )
            return ConversationHandler.END
        
        try:
            bot_member = await chat.get_member(context.bot.id)
            if bot_member.status not in [ChatMember.ADMINISTRATOR, ChatMember.OWNER]:
                await message.reply_text(
                    "❌ <b>Бот не является администратором!</b>\n\n"
                    "Для работы бота необходимо:\n"
                    "1. Сделать бота администратором группы\n"
                    "2. Выдать права на отправку сообщений\n"
                    "3. Попробовать снова",
                    parse_mode=ParseMode.HTML
                )
                return ConversationHandler.END
        except Exception as e:
            logger.error(f"Ошибка проверки прав бота в группе {chat.id}: {e}")
            await message.reply_text(
                "❌ <b>Ошибка проверки прав бота!</b>\n\n"
                "Убедитесь, что бот добавлен в группу.",
                parse_mode=ParseMode.HTML
            )
            return ConversationHandler.END
        
        success = db.bind_group(chat.id, chat.title, user.id)
        
        if success:
            logger.info(f"✅ Группа {chat.title} ({chat.id}) привязана пользователем {user.id}")
            
            await message.reply_text(
                f"✅ <b>Группа успешно привязана!</b>\n\n"
                f"📌 <b>Название:</b> {chat.title}\n"
                f"🆔 <b>ID:</b> <code>{chat.id}</code>\n\n"
                f"<b>Теперь вы можете:</b>\n"
                f"• 📝 Создавать посты\n"
                f"• 🗳️ Создавать голосования\n"
                f"• 🗑️ Удалять сообщения",
                parse_mode=ParseMode.HTML
            )
        else:
            logger.error(f"❌ Ошибка привязки группы {chat.id} пользователем {user.id}")
            await message.reply_text(
                "❌ <b>Ошибка при привязке группы!</b>\n\n"
                "Попробуйте еще раз. Если ошибка повторяется, обратитесь к разработчику.",
                parse_mode=ParseMode.HTML
            )
        
        return ConversationHandler.END
    
    @staticmethod
    async def my_groups_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Команда /my_groups"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, 
                update.message if update.message else update.callback_query.message)
        
        user = update.effective_user
        message = update.message or (update.callback_query.message if update.callback_query else None)
        
        groups = db.get_user_groups(user.id)
        
        if not groups:
            await message.reply_text(
                "❌ Нет привязанных групп\n\n"
                "Добавьте бота в группу как администратора и используйте /bind_group",
                reply_markup=Keyboards.back_button()
            )
            return ConversationHandler.END
        
        logger.info(f"Пользователь {user.id} запросил список своих групп: {len(groups)} групп")
        
        await message.reply_text(
            f"📋 <b>Ваши группы</b> ({len(groups)}):",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.groups_list(groups, 'group_info')
        )
        return ConversationHandler.END
    
    
    @staticmethod
    async def create_post_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Начало создания поста"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context,
                update.message if update.message else update.callback_query.message)
        
        user = update.effective_user
        message = update.message or (update.callback_query.message if update.callback_query else None)
        
        if update.callback_query:
            try:
                await update.callback_query.answer()
            except:
                pass
        
        groups = db.get_user_groups(user.id)
        
        if not groups:
            await message.reply_text(
                "❌ Нет привязанных групп\n\n"
                "Сначала добавьте бота в группу и используйте /bind_group",
                reply_markup=Keyboards.back_button()
            )
            return ConversationHandler.END
        
        context.user_data['post_data'] = {}
        
        logger.info(f"Пользователь {user.id} начал создание поста")
        
        await message.reply_text(
            "📝 <b>Создание поста</b>\n\n"
            "Выберите группу:",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.groups_list(groups, 'select_group_post')
        )
        return States.SELECTING_GROUP
    
    @staticmethod
    async def select_group_for_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор группы для поста"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context)
        
        query = update.callback_query
        await query.answer()
        
        if query.data.startswith('select_group_post_'):
            try:
                group_id = int(query.data.split('_')[3])
                group_info = db.get_group_info(group_id)
                
                if group_info:
                    context.user_data['post_data'] = {
                        'group_id': group_id,
                        'group_title': group_info[1],
                        'type': None,
                        'telegram_chat_id': Utils.convert_to_telegram_chat_id(group_id)
                    }
                    
                    logger.info(f"Выбрана группа для поста: {group_info[1]} ({group_id})")
                    
                    await query.message.edit_text(
                        f"✅ <b>Группа выбрана:</b> {group_info[1]}\n\n"
                        "Выберите тип поста:",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.post_type_selection()
                    )
                    return States.SELECTING_POST_TYPE
                    
            except Exception as e:
                logger.error(f"Ошибка выбора группы: {e}")
                await query.message.reply_text("❌ Ошибка!")
                return ConversationHandler.END
        
        return States.SELECTING_GROUP
    
    @staticmethod
    async def select_post_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор типа поста"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context)
        
        query = update.callback_query
        await query.answer()
        
        data = query.data
        post_data = context.user_data.get('post_data', {})
        
        if data == 'post_type_text':
            post_data['type'] = 'text'
            logger.info(f"Выбран тип поста: текстовый")
            
            await query.message.edit_text(
                f"✏️ <b>Текстовый пост</b>\n\n"
                f"🏷️ <b>Группа:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
                "Напишите текст поста (можно с медиа):\n\n",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.WRITING_POST
            
        elif data == 'post_type_forward':
            post_data['type'] = 'forward'
            logger.info(f"Выбран тип поста: переслать сообщение")
            
            await query.message.edit_text(
                f"📨 <b>Переслать сообщение</b>\n\n"
                f"🏷️ <b>Группа:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
                "Перешлите сообщение, которое хотите отправить "
                "(можно переслать из любого чата):",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.WRITING_POST
            
        elif data == 'post_type_reply':
            post_data['type'] = 'reply'
            logger.info(f"Выбран тип поста: ответить на сообщение")
            
            await query.message.edit_text(
                f"💬 <b>Ответить на сообщение</b>\n\n"
                f"🏷️ <b>Группа:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
                "Отправьте ссылку на сообщение, на которое нужно ответить:\n\n"
                "<b>Примеры ссылок:</b>\n"
                "• https://t.me/c/2819799004/1/27440 - приватная группа с темой\n"
                "• https://t.me/c/2819799004/27440 - приватная группа без темы\n"
                "• https://t.me/username/123 - публичная группа\n\n"
                "<i>Бот должен иметь доступ к сообщению!</i>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.REPLY_MESSAGE
        
        return States.SELECTING_POST_TYPE

    @staticmethod
    async def receive_post_content(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение контента для поста с сохранением ПОЛНОГО форматирования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        post_data = context.user_data.get('post_data', {})
        post_type = post_data.get('type')
        
        if post_type == 'text':
            if update.message.sticker:
                post_data['has_media'] = True
                post_data['media_type'] = 'sticker'
                post_data['sticker_file_id'] = update.message.sticker.file_id
                post_data['media'] = {
                    'message_id': update.message.message_id,
                    'chat_id': update.effective_chat.id,
                }
                
                if hasattr(update.message.sticker, 'premium_animation') and update.message.sticker.premium_animation:
                    post_data['is_premium_sticker'] = True
                    logger.info(f"🔥 Получен PREMIUM стикер!")
                
                if update.message.caption:
                    post_data['text'] = update.message.caption
                    if update.message.caption_entities:
                        has_premium = False
                        for entity in update.message.caption_entities:
                            if entity.type == "custom_emoji":
                                has_premium = True
                                break
                        
                        if has_premium:
                            post_data['use_copy'] = True
                            post_data['copy_message'] = {
                                'message_id': update.message.message_id,
                                'chat_id': update.effective_chat.id,
                            }
                            logger.info(f"✨ Premium эмодзи в подписи к стикеру - будем копировать")
                        else:
                            post_data['entities'] = update.message.caption_entities
                
                await update.message.reply_text(
                    "✅ <b>Стикер получен!</b>\n\n"
                    "Добавить кнопки под постом?",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.button_options()
                )
                return States.SELECTING_BUTTON_OPTION
            
            elif update.message.text and update.message.entities:
                has_premium = False
                for entity in update.message.entities:
                    if entity.type == "custom_emoji":
                        has_premium = True
                        break
                
                if has_premium:
                    post_data['use_copy'] = True
                    post_data['copy_message'] = {
                        'message_id': update.message.message_id,
                        'chat_id': update.effective_chat.id,
                    }
                    post_data['text'] = update.message.text
                    post_data['entities'] = update.message.entities
                    
                    premium_count = sum(1 for e in update.message.entities if e.type == "custom_emoji")
                    logger.info(f"✨ Обнаружено {premium_count} Premium эмодзи - БУДЕМ КОПИРОВАТЬ")
                    
                    await update.message.reply_text(
                        "✅ <b>Premium эмодзи получены!</b>\n\n"
                        "Сообщение будет скопировано целиком для сохранения эмодзи.\n\n"
                        "Добавить кнопки под постом?",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.button_options()
                    )
                    return States.SELECTING_BUTTON_OPTION
                else:
                    post_data['text'] = update.message.text
                    post_data['entities'] = update.message.entities
                    post_data['use_copy'] = False
                    logger.info(f"📝 Получен текст с {len(update.message.entities)} entities форматирования")
                    
                    await update.message.reply_text(
                        "✅ <b>Текст с форматированием получен!</b>\n\n"
                        "Добавить кнопки под постом?",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.button_options()
                    )
                    return States.SELECTING_BUTTON_OPTION
            
            elif (update.message.photo or update.message.video or 
                update.message.document or update.message.audio or
                update.message.voice or update.message.animation):
                
                post_data['has_media'] = True
                post_data['media'] = {
                    'message_id': update.message.message_id,
                    'chat_id': update.effective_chat.id,
                }
                post_data['use_copy'] = True
                
                if update.message.photo:
                    post_data['media_type'] = 'photo'
                elif update.message.video:
                    post_data['media_type'] = 'video'
                elif update.message.document:
                    post_data['media_type'] = 'document'
                elif update.message.audio:
                    post_data['media_type'] = 'audio'
                elif update.message.voice:
                    post_data['media_type'] = 'voice'
                elif update.message.animation:
                    post_data['media_type'] = 'animation'
                
                if update.message.caption:
                    post_data['text'] = update.message.caption
                    if update.message.caption_entities:
                        has_premium = False
                        for entity in update.message.caption_entities:
                            if entity.type == "custom_emoji":
                                has_premium = True
                                break
                        
                        if has_premium:
                            post_data['copy_message'] = {
                                'message_id': update.message.message_id,
                                'chat_id': update.effective_chat.id,
                            }
                            logger.info(f"✨ Premium эмодзи в подписи к медиа")
                        else:
                            post_data['entities'] = update.message.caption_entities
                
                await update.message.reply_text(
                    "✅ <b>Медиа получено!</b>\n\n"
                    "Добавить кнопки под постом?",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.button_options()
                )
                return States.SELECTING_BUTTON_OPTION
            
            elif update.message.text:
                text = update.message.text
                if not text.strip():
                    await update.message.reply_text(
                        "❌ <b>Отправьте текстовое сообщение!</b>",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.cancel_button()
                    )
                    return States.WRITING_POST
                
                post_data['text'] = text
                post_data['use_copy'] = False
                logger.info(f"📝 Получен обычный текст: {len(text)} символов")
                
                await update.message.reply_text(
                    "✅ <b>Текст получен!</b>\n\n"
                    "Добавить кнопки под постом?",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.button_options()
                )
                return States.SELECTING_BUTTON_OPTION
            else:
                await update.message.reply_text(
                    "❌ <b>Отправьте текстовое сообщение или медиа!</b>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.WRITING_POST
                
        elif post_type == 'forward':
            if not (update.message.forward_date or update.message.forward_from or 
                update.message.forward_from_chat or update.message.forward_sender_name):
                await update.message.reply_text(
                    "❌ <b>Это не пересланное сообщение!</b>\n\n"
                    "Пожалуйста, перешлите сообщение из другого чата.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.WRITING_POST
            
            post_data['forward_message'] = {
                'message_id': update.message.message_id,
                'chat_id': update.effective_chat.id,
                'is_forward': True
            }
            post_data['use_copy'] = True
            
            logger.info(f"📨 Получено сообщение для пересылки")
            
            await update.message.reply_text(
                "✅ <b>Сообщение получено для пересылки!</b>\n\n"
                "Добавить кнопки под постом?",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.button_options()
            )
            return States.SELECTING_BUTTON_OPTION
        
        return States.WRITING_POST

    @staticmethod
    async def select_button_option(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор опции добавления кнопок"""
        query = update.callback_query
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                logger.debug(f"Пропускаем устаревший запрос")
                return ConversationHandler.END
            return ConversationHandler.END
        
        data = query.data
        post_data = context.user_data.get('post_data', {})
        
        if data == 'button_yes':
            post_data['has_buttons'] = True
            
            await query.message.edit_text(
                "🛠️ <b>Добавление кнопок</b>\n\n"
                "Введите кнопки в формате:\n\n"
                "<code>Название кнопки - https://ссылка.com</code>\n\n"
                "<b>Пример:</b>\n"
                "<code>Наш сайт - https://example.com</code>\n"
                "<code>Telegram - https://t.me/channel</code>\n"
                "<code>Поддержка - https://t.me/username</code>\n\n"
                "Можно добавить до 100 кнопок.\n"
                "Каждая кнопка на новой строке.\n"
                "Формат: <b>Название - URL</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.ADDING_BUTTONS
            
        elif data == 'button_no':
            post_data['has_buttons'] = False
            
            await query.message.edit_text(
                "✅ <b>Кнопки не будут добавлены</b>\n\n"
                "Хотите упомянуть участников группы?",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.mention_options()
            )
            return States.SELECTING_MENTION_OPTION
        
        return States.SELECTING_BUTTON_OPTION
    
    @staticmethod
    async def receive_buttons_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение ввода кнопок"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        post_data = context.user_data.get('post_data', {})
        buttons_text = update.message.text.strip()
        
        buttons = []
        errors = []
        
        lines = buttons_text.split('\n')
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue
                
            if ' - ' in line:
                parts = line.split(' - ', 1)
            elif '-' in line:
                parts = line.split('-', 1)
            else:
                errors.append(f"Строка {i}: Неверный формат. Используйте 'Название - URL'")
                continue
            
            if len(parts) != 2:
                errors.append(f"Строка {i}: Неверный формат. Используйте 'Название - URL'")
                continue
            
            name = parts[0].strip()
            url = parts[1].strip()
            
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            
            if not re.match(r'^https?://[^\s]+$', url):
                errors.append(f"Строка {i}: Неверный URL '{url}'")
                continue
            
            if len(name) > 32:
                errors.append(f"Строка {i}: Название кнопки слишком длинное (макс. 32 символа)")
                continue
            
            if not name:
                errors.append(f"Строка {i}: Название кнопки не может быть пустым")
                continue
            
            buttons.append({'text': name, 'url': url})
        
        if errors:
            error_msg = "\n".join(errors[:5])
            if len(errors) > 5:
                error_msg += f"\n\n... и еще {len(errors) - 5} ошибок"
            
            await update.message.reply_text(
                f"❌ <b>Ошибки в формате кнопок:</b>\n\n{error_msg}\n\n"
                "Исправьте ошибки и отправьте кнопки заново:\n\n"
                "<b>Примеры:</b>\n"
                "<code>📢 Канал - https://t.me/channel</code>\n"
                "<code>💬 Чат - https://t.me/chat</code>\n"
                "<code>🌐 Сайт - https://example.com</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.ADDING_BUTTONS
        
        if not buttons:
            await update.message.reply_text(
                "❌ <b>Не указано ни одной кнопки!</b>\n\n"
                "Отправьте кнопки в формате:\n"
                "<code>Название - https://ссылка.com</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.ADDING_BUTTONS
        
        post_data['buttons'] = buttons
        result = db.save_post_buttons(update.effective_user.id, str(buttons))
        
        if result:
            logger.info(f"✅ Добавлено {len(buttons)} кнопок")
        else:
            logger.error("❌ Ошибка сохранения кнопок в БД")
        
        preview_text = "✅ <b>Кнопки добавлены:</b>\n\n"
        for btn in buttons:
            preview_text += f"• <code>{btn['text']}</code> -> {btn['url']}\n"
        
        await update.message.reply_text(
            preview_text + "\nХотите упомянуть участников группы?",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.mention_options()
        )
        return States.SELECTING_MENTION_OPTION

    @staticmethod
    async def select_mention_option(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор опции упоминаний"""
        query = update.callback_query
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                logger.debug(f"Пропускаем устаревший запрос")
                return ConversationHandler.END
            return ConversationHandler.END
        
        data = query.data
        post_data = context.user_data.get('post_data', {})
        
        if data == 'mention_all':
            post_data['mention_type'] = 'all'
            post_data['mention_role'] = None
            group_id = post_data.get('group_id')
            if group_id:
                telegram_chat_id = post_data.get('telegram_chat_id', group_id)
                try:
                    members = await Utils.get_all_members(context.bot, telegram_chat_id)
                    usernames = []
                    for member in members:
                        username = member.get('username')
                        if username:
                            usernames.append(f"@{username}")
                    
                    if usernames:
                        post_data['mentions_text'] = ", ".join(usernames) + "\n\n"
                    else:
                        post_data['mentions_text'] = ""
                    
                    logger.info(f"Сгенерированы упоминания для {len(usernames)} участников")
                except Exception as e:
                    logger.error(f"Ошибка получения участников: {e}")
                    post_data['mentions_text'] = ""
            
            if post_data.get('type') == 'reply':
                await query.message.edit_text(
                    "✅ <b>Настройки упоминаний сохранены!</b>\n\n"
                    "Теперь напишите текст ответа (можно с медиа):",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.REPLY_TEXT
            else:
                await query.message.edit_text(
                    "✅ <b>Настройки упоминаний сохранены!</b>\n\n"
                    "Теперь укажите тему:\n\n"
                    "<b>Форматы:</b>\n"
                    "• https://t.me/c/3692121714/14 - ссылка на тему\n"
                    "• 14 - ID темы\n"
                    "• 'нет' или 'пропустить' - основная лента\n\n"
                    "<i>Тема должна существовать в группе!</i>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.SELECTING_TOPIC
            
        elif data == 'mention_role':
            post_data['mention_type'] = 'role'
            post_data['mentions_text'] = ""
            
            roles = RolesManager.get_role_names()
            
            if not roles:
                await query.message.edit_text(
                    "❌ <b>Роли не найдены!</b>\n\n"
                    "Создайте файл roles.txt в формате:\n"
                    "<code>Название роли - @username1, @username2</code>\n\n"
                    "Выберите другой вариант упоминания:",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.mention_options()
                )
                return States.SELECTING_MENTION_OPTION
            
            await query.message.edit_text(
                "🎭 <b>Выбор роли для упоминания</b>\n\n"
                f"🏷️ <b>Группа:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
                f"<b>Доступные роли:</b> {len(roles)}\n\n"
                "Выберите роль из списка:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.role_selection()
            )
            return States.SELECTING_ROLE
            
        elif data == 'mention_none':
            post_data['mention_type'] = 'none'
            post_data['mention_role'] = None
            post_data['mentions_text'] = ""
            
            if post_data.get('type') == 'reply':
                await query.message.edit_text(
                    "✅ <b>Настройки упоминаний сохранены!</b>\n\n"
                    "Теперь напишите текст ответа (можно с медиа):",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.REPLY_TEXT
            else:
                await query.message.edit_text(
                    "✅ <b>Настройки упоминаний сохранены!</b>\n\n"
                    "Теперь укажите тему:\n\n"
                    "<b>Форматы:</b>\n"
                    "• https://t.me/c/3692121714/14 - ссылка на тему\n"
                    "• 14 - ID темы\n"
                    "• 'нет' или 'пропустить' - основная лента\n\n"
                    "<i>Тема должна существовать в группе!</i>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.SELECTING_TOPIC
        
        return States.SELECTING_MENTION_OPTION
    
    @staticmethod
    async def select_role_for_mention(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор роли для упоминания"""
        query = update.callback_query
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                logger.debug(f"Пропускаем устаревший запрос")
                return ConversationHandler.END
            return ConversationHandler.END
        
        data = query.data
        
        if data == 'no_roles':
            await query.message.edit_text(
                "❌ <b>Роли не найдены!</b>\n\n"
                "Создайте файл roles.txt в формате:\n"
                "<code>Название роли - @username1, @username2</code>\n\n"
                "Выберите другой вариант упоминания:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.mention_options()
            )
            return States.SELECTING_MENTION_OPTION
        
        if data.startswith('role_'):
            try:
                role_name = data[5:]
                post_data = context.user_data.get('post_data', {})
                usernames = RolesManager.get_usernames_by_role(role_name)
                
                if usernames:
                    mentions = [f"@{username}" for username in usernames]
                    post_data['mention_role'] = role_name
                    post_data['mentions_text'] = ", ".join(mentions) + "\n\n"
                    
                    logger.info(f"✅ Выбрана роль '{role_name}' с {len(usernames)} участниками")
                    
                    if post_data.get('type') == 'reply':
                        await query.message.edit_text(
                            f"✅ <b>Выбрана роль: {role_name}</b> ({len(usernames)} участников)\n\n"
                            "Теперь напишите текст ответа (можно с медиа):",
                            parse_mode=ParseMode.HTML,
                            reply_markup=Keyboards.cancel_button()
                        )
                        return States.REPLY_TEXT
                    else:
                        await query.message.edit_text(
                            f"✅ <b>Выбрана роль: {role_name}</b> ({len(usernames)} участников)\n\n"
                            "Теперь укажите тему:\n\n"
                            "<b>Форматы:</b>\n"
                            "• https://t.me/c/3692121714/14 - ссылка на тему\n"
                            "• 14 - ID темы\n"
                            "• 'нет' или 'пропустить' - основная лента\n\n"
                            "<i>Тема должна существовать в группе!</i>",
                            parse_mode=ParseMode.HTML,
                            reply_markup=Keyboards.cancel_button()
                        )
                        return States.SELECTING_TOPIC
                else:
                    await query.message.edit_text(
                        f"❌ <b>Роль '{role_name}' не содержит участников!</b>\n\n"
                        "Выберите другую роль:",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.role_selection()
                    )
                    return States.SELECTING_ROLE
                    
            except Exception as e:
                logger.error(f"Ошибка выбора роли: {e}")
                await query.message.edit_text(
                    "❌ <b>Ошибка выбора роли!</b>\n\n"
                    "Попробуйте еще раз:",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.mention_options()
                )
                return States.SELECTING_MENTION_OPTION
        
        return States.SELECTING_ROLE
    
    @staticmethod
    async def receive_message_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение ссылки на сообщение для ответа"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        post_data = context.user_data.get('post_data', {})
        message_link = update.message.text.strip()
        
        link_info = Utils.parse_message_link(message_link)
        
        if not link_info:
            await update.message.reply_text(
                "❌ <b>Неверная ссылка!</b>\n\n"
                "Пожалуйста, отправьте корректную ссылку на сообщение.\n\n"
                "<b>Примеры:</b>\n"
                "• https://t.me/c/2819799004/1/27440 - приватная группа с темой\n"
                "• https://t.me/c/2819799004/27440 - приватная группа без темы\n"
                "• https://t.me/username/123 - публичная группа",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.REPLY_MESSAGE
        
        post_data['reply_link'] = link_info
        
        if link_info.get('topic_id'):
            post_data['topic_id'] = link_info.get('topic_id')
            logger.info(f"Тема из ссылки: {link_info.get('topic_id')}, ID сообщения: {link_info.get('message_id')}")
        
        await update.message.reply_text(
            "✅ <b>Ссылка сохранена!</b>\n\n"
            "Теперь напишите текст ответа (можно с медиа):",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.cancel_button()
        )
        return States.REPLY_TEXT
    
    @staticmethod
    async def receive_reply_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение текста ответа с сохранением форматирования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        post_data = context.user_data.get('post_data', {})
        
        if update.message.sticker:
            post_data['has_media'] = True
            post_data['media_type'] = 'sticker'
            post_data['sticker_file_id'] = update.message.sticker.file_id
            post_data['media'] = {
                'message_id': update.message.message_id,
                'chat_id': update.effective_chat.id,
            }
            
            if hasattr(update.message.sticker, 'premium_animation') and update.message.sticker.premium_animation:
                post_data['is_premium_sticker'] = True
            
            post_data['reply_text'] = update.message.caption or ""
            if update.message.caption_entities:
                post_data['entities'] = update.message.caption_entities
                post_data['has_entities'] = True
            logger.info("📦 Получен стикер для ответа")
        
        elif update.message.text and update.message.entities:
            post_data['reply_text'] = update.message.text
            post_data['entities'] = update.message.entities
            post_data['has_entities'] = True
            
            premium_count = 0
            for entity in update.message.entities:
                if entity.type == "custom_emoji":
                    premium_count += 1
            
            if premium_count > 0:
                post_data['has_premium_emoji'] = True
                logger.info(f"✨ Получено {premium_count} Premium эмодзи в ответе")
            else:
                logger.info(f"📝 Получен текст для ответа с {len(update.message.entities)} entities")
        
        elif update.message.photo or update.message.video or update.message.document or update.message.audio or update.message.voice or update.message.animation:
            post_data['has_media'] = True
            post_data['media'] = {
                'message_id': update.message.message_id,
                'chat_id': update.effective_chat.id,
            }
            
            if update.message.photo:
                post_data['media_type'] = 'photo'
            elif update.message.video:
                post_data['media_type'] = 'video'
            elif update.message.document:
                post_data['media_type'] = 'document'
            elif update.message.audio:
                post_data['media_type'] = 'audio'
            elif update.message.voice:
                post_data['media_type'] = 'voice'
            elif update.message.animation:
                post_data['media_type'] = 'animation'
            
            post_data['reply_text'] = update.message.caption or ""
            if update.message.caption_entities:
                post_data['entities'] = update.message.caption_entities
                post_data['has_entities'] = True
            logger.info(f"📁 Получено медиа для ответа: {post_data['media_type']}")
        
        elif update.message.text:
            post_data['reply_text'] = update.message.text
            post_data['has_entities'] = False
            logger.info(f"📝 Получен обычный текст для ответа")
        else:
            await update.message.reply_text(
                "❌ <b>Отправьте текстовое сообщение или медиа!</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.REPLY_TEXT
        
        logger.info("📤 Отправка reply поста...")
        success = await Handlers.send_post(context)
        
        if success:
            logger.info("✅ Сообщение успешно отправлено")
            await update.message.reply_text(
                "✅ <b>Сообщение успешно отправлено!</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        else:
            logger.error("❌ Ошибка при отправке сообщения")
            await update.message.reply_text(
                "❌ <b>Ошибка при отправке сообщения!</b>\n\n"
                "Проверьте права бота в группе.",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        
        if 'post_data' in context.user_data:
            context.user_data.pop('post_data', None)
        
        return ConversationHandler.END

    @staticmethod
    async def receive_topic_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение ввода темы"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        post_data = context.user_data.get('post_data', {})
        user_input = update.message.text.strip().lower()
        
        logger.info(f"Получена тема: {user_input}")
        
        if post_data.get('type') == 'reply':
            logger.info("Пропускаем выбор темы для reply, тема уже определена из ссылки")
            success = await Handlers.send_post(context)
            
            if success:
                logger.info("✅ Сообщение успешно отправлено")
                await update.message.reply_text(
                    "✅ <b>Сообщение успешно отправлено!</b>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.main_menu()
                )
            else:
                logger.error("❌ Ошибка при отправке сообщения")
                await update.message.reply_text(
                    "❌ <b>Ошибка при отправке сообщения!</b>\n\n"
                    "Проверьте права бота в группе.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.main_menu()
                )
            
            if 'post_data' in context.user_data:
                context.user_data.pop('post_data', None)
            
            return ConversationHandler.END
        
        if user_input in ['нет', 'no', 'skip', 'пропустить', 'основная', 'main', '0', 'основной', '']:
            post_data['topic_id'] = None
            logger.info("Выбрана основная лента (без темы)")
        else:
            topic_id = Utils.parse_topic_link(user_input)
            
            if topic_id is None:
                try:
                    numbers = re.findall(r'\d+', user_input)
                    if numbers:
                        topic_id = int(numbers[-1])
                    else:
                        raise ValueError("Не найдены числа в вводе")
                except ValueError:
                    await update.message.reply_text(
                        "❌ <b>Неверный формат темы!</b>\n\n"
                        "Пожалуйста, укажите:\n"
                        "1. Ссылку на тему (например: https://t.me/c/1234567890/14)\n"
                        "2. ID темы (число, начиная с 2)\n"
                        "3. 'нет' для основной ленты\n\n"
                        "<b>ВАЖНО:</b> Тема 1 - это основная лента, используйте ID темы начиная с 2",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.cancel_button()
                    )
                    return States.SELECTING_TOPIC
            
            if topic_id == 1:
                post_data['topic_id'] = None
                logger.info("Тема 1 обнаружена, отправляю в основную ленту")
                await update.message.reply_text(
                    "ℹ️ <b>Тема 1 - это основная лента.</b>\nСообщение будет отправлено в основную ленту.",
                    parse_mode=ParseMode.HTML
                )
            else:
                post_data['topic_id'] = topic_id
                logger.info(f"Установлена тема: {topic_id}")
        
        logger.info("📤 Отправка поста...")
        
        success = await Handlers.send_post(context)
        
        if success:
            logger.info("✅ Сообщение успешно отправлено")
            await update.message.reply_text(
                "✅ <b>Сообщение успешно отправлено!</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        else:
            logger.error("❌ Ошибка при отправке сообщения")
            await update.message.reply_text(
                "❌ <b>Ошибка при отправке сообщения!</b>\n\n"
                "Проверьте права бота в группе.",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        
        if 'post_data' in context.user_data:
            context.user_data.pop('post_data', None)
        
        return ConversationHandler.END
    
    
    @staticmethod
    async def create_poll_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Начало создания голосования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context,
                update.message if update.message else update.callback_query.message)
        
        user = update.effective_user
        message = update.message or (update.callback_query.message if update.callback_query else None)
        
        if update.callback_query:
            try:
                await update.callback_query.answer()
            except:
                pass
        
        groups = db.get_user_groups(user.id)
        
        if not groups:
            await message.reply_text(
                "❌ Нет привязанных групп\n\n"
                "Сначала добавьте бота в группу и используйте /bind_group",
                reply_markup=Keyboards.back_button()
            )
            return ConversationHandler.END
        
        context.user_data['poll_data'] = {
            'group_id': None,
            'group_title': None,
            'telegram_chat_id': None,
            'question': None,
            'options': [],
            'poll_type': None,
            'is_anonymous': False,
            'allows_multiple_answers': False,
            'is_quiz': False,
            'correct_option_id': None,
            'explanation': None,
            'open_period': None,
            'topic_id': None
        }
        
        logger.info(f"Пользователь {user.id} начал создание голосования")
        
        await message.reply_text(
            "🗳️ <b>Создание голосования</b>\n\n"
            "Выберите группу:",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.groups_list(groups, 'select_group_poll')
        )
        return States.SELECTING_GROUP

    @staticmethod
    async def select_group_for_poll(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор группы для голосования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context)
        
        query = update.callback_query
        await query.answer()
        
        if query.data.startswith('select_group_poll_'):
            try:
                group_id = int(query.data.split('_')[3])
                group_info = db.get_group_info(group_id)
                
                if group_info:
                    context.user_data['poll_data']['group_id'] = group_id
                    context.user_data['poll_data']['group_title'] = group_info[1]
                    context.user_data['poll_data']['telegram_chat_id'] = Utils.convert_to_telegram_chat_id(group_id)
                    
                    logger.info(f"Выбрана группа для голосования: {group_info[1]} ({group_id})")
                    
                    await query.message.edit_text(
                        f"✅ <b>Группа выбрана:</b> {group_info[1]}\n\n"
                        "📝 <b>Напишите вопрос для голосования</b>\n\n"
                        "Можно использовать:\n"
                        "• Обычный текст\n"
                        "• Эмодзи ✅ ❌ 📊\n\n"
                        "<i>Premium эмодзи не поддерживаются API Telegram</i>\n\n"
                        "Пример: ❓ Какую функцию добавить?",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.cancel_poll_button()
                    )
                    return States.WRITING_POLL_QUESTION
                    
            except Exception as e:
                logger.error(f"Ошибка выбора группы: {e}")
                await query.message.reply_text("❌ Ошибка!")
                return ConversationHandler.END
        
        return States.SELECTING_GROUP

    @staticmethod
    async def receive_poll_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение вопроса для голосования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        poll_data = context.user_data.get('poll_data', {})
        question = update.message.text.strip()
        
        if not question:
            await update.message.reply_text(
                "❌ <b>Вопрос не может быть пустым!</b>\n\n"
                "Напишите вопрос для голосования:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_QUESTION
        
        if len(question) > 300:
            await update.message.reply_text(
                "❌ <b>Вопрос слишком длинный!</b>\n\n"
                "Максимум 300 символов.",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_QUESTION
        
        poll_data['question'] = question
        logger.info(f"Получен вопрос для голосования: {question[:50]}...")
        
        await update.message.reply_text(
            "✅ <b>Вопрос сохранен!</b>\n\n"
            "📋 <b>Напишите варианты ответов</b>\n\n"
            "Каждый вариант с новой строки:\n\n"
            "✅ Новая функция\n"
            "🔄 Исправить баги\n"
            "⚡ Улучшить производительность\n"
            "❌ Ничего не менять\n\n"
            "📌 <b>Требования:</b>\n"
            "• Минимум 2 варианта\n"
            "• Максимум 10 вариантов\n"
            "• До 100 символов на вариант\n\n"
            "<i>Premium эмодзи не поддерживаются API Telegram</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.cancel_poll_button()
        )
        return States.WRITING_POLL_OPTIONS

    @staticmethod
    async def receive_poll_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение вариантов ответов для голосования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        poll_data = context.user_data.get('poll_data', {})
        options_text = update.message.text.strip()
        
        if not options_text:
            await update.message.reply_text(
                "❌ <b>Нужно указать хотя бы 2 варианта ответа!</b>\n\n"
                "Напишите варианты ответов, каждый с новой строки:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_OPTIONS
        
        options = [opt.strip() for opt in options_text.split('\n') if opt.strip()]
        
        if len(options) < 2:
            await update.message.reply_text(
                "❌ <b>Нужно указать хотя бы 2 варианта ответа!</b>\n\n"
                f"Вы указали только {len(options)} вариант(ов).",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_OPTIONS
        
        if len(options) > 10:
            await update.message.reply_text(
                "❌ <b>Слишком много вариантов ответа!</b>\n\n"
                f"Максимум 10 вариантов, вы указали {len(options)}.\n"
                "Укажите меньше вариантов:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_OPTIONS
        
        long_options = [opt for opt in options if len(opt) > 100]
        if long_options:
            await update.message.reply_text(
                "❌ <b>Слишком длинные варианты ответа!</b>\n\n"
                "Максимум 100 символов на вариант.\n"
                "Сократите следующие варианты:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.WRITING_POLL_OPTIONS
        
        poll_data['options'] = options
        logger.info(f"Получено {len(options)} вариантов ответа")
        
        options_list = "\n".join([f"{i+1}. {opt}" for i, opt in enumerate(options)])
        
        await update.message.reply_text(
            f"✅ <b>Варианты ответов сохранены:</b>\n\n{options_list}\n\n"
            "🎯 <b>Выберите тип голосования:</b>\n\n"
            "📊 <b>Обычное</b> - 1 вариант, не анонимно\n"
            "📋 <b>Множественный выбор</b> - можно выбрать несколько\n"
            "🎓 <b>Викторина</b> - с правильным ответом\n"
            "🙈 <b>Анонимное</b> - никто не видит, кто голосовал",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.poll_type_selection()
        )
        return States.SELECTING_POLL_TYPE

    @staticmethod
    async def select_poll_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор типа голосования"""
        query = update.callback_query
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                return ConversationHandler.END
            return ConversationHandler.END
        
        data = query.data
        poll_data = context.user_data.get('poll_data', {})
        
        if data == 'poll_type_regular':
            poll_data['poll_type'] = 'regular'
            poll_data['is_anonymous'] = False
            poll_data['allows_multiple_answers'] = False
            poll_data['is_quiz'] = False
            poll_data['correct_option_id'] = None
            
            logger.info("📊 Выбран тип: обычное голосование")
            
            await query.message.edit_text(
                "✅ <b>Обычное голосование</b>\n\n"
                "📌 <b>Характеристики:</b>\n"
                "• Можно выбрать только 1 вариант\n"
                "• Имена голосующих видны\n\n"
                "📝 <b>Укажите тему сообщения:</b>\n\n"
                "• Отправьте <b>ID темы</b> (число)\n"
                "• Отправьте <b>ссылку на тему</b>\n"
                "• Отправьте <b>нет</b> для основной ленты\n\n"
                "Пример: <code>14</code> или <code>https://t.me/c/123456789/14</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.SELECTING_POLL_TOPIC
            
        elif data == 'poll_type_multiple':
            poll_data['poll_type'] = 'multiple'
            poll_data['is_anonymous'] = False
            poll_data['allows_multiple_answers'] = True
            poll_data['is_quiz'] = False
            poll_data['correct_option_id'] = None
            
            logger.info("📋 Выбран тип: множественный выбор")
            
            await query.message.edit_text(
                "✅ <b>Множественный выбор</b>\n\n"
                "📌 <b>Характеристики:</b>\n"
                "• Можно выбрать НЕСКОЛЬКО вариантов\n"
                "• Имена голосующих видны\n\n"
                "📝 <b>Укажите тему сообщения:</b>\n\n"
                "• Отправьте <b>ID темы</b> (число)\n"
                "• Отправьте <b>ссылку на тему</b>\n"
                "• Отправьте <b>нет</b> для основной ленты",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.SELECTING_POLL_TOPIC
            
        elif data == 'poll_type_quiz':
            poll_data['poll_type'] = 'quiz'
            poll_data['is_anonymous'] = False
            poll_data['allows_multiple_answers'] = False
            poll_data['is_quiz'] = True
            
            options_count = len(poll_data.get('options', []))
            
            if options_count > 0:
                logger.info("🎓 Выбран тип: викторина")
                
                await query.message.edit_text(
                    "🎓 <b>Викторина</b>\n\n"
                    "📌 <b>Характеристики:</b>\n"
                    "• Есть ПРАВИЛЬНЫЙ ответ\n"
                    "• Можно добавить объяснение\n\n"
                    "✅ <b>Выберите номер правильного ответа:</b>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.select_correct_option(options_count)
                )
                return States.WRITING_QUIZ_CORRECT_ANSWER
            else:
                await query.message.edit_text(
                    "❌ <b>Нет вариантов ответа!</b>\n\n"
                    "Сначала укажите варианты ответов.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.poll_back_button()
                )
                return States.SELECTING_POLL_TYPE
                
        elif data == 'poll_type_anonymous':
            poll_data['poll_type'] = 'anonymous'
            poll_data['is_anonymous'] = True
            poll_data['allows_multiple_answers'] = False
            poll_data['is_quiz'] = False
            poll_data['correct_option_id'] = None
            
            logger.info("🙈 Выбран тип: анонимное голосование")
            
            await query.message.edit_text(
                "✅ <b>Анонимное голосование</b>\n\n"
                "📌 <b>Характеристики:</b>\n"
                "• Можно выбрать только 1 вариант\n"
                "• Имена голосующих НЕ видны\n\n"
                "📝 <b>Укажите тему сообщения:</b>\n\n"
                "• Отправьте <b>ID темы</b> (число)\n"
                "• Отправьте <b>ссылку на тему</b>\n"
                "• Отправьте <b>нет</b> для основной ленты",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_poll_button()
            )
            return States.SELECTING_POLL_TOPIC
        
        return States.SELECTING_POLL_TYPE

    @staticmethod
    async def select_correct_option(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Выбор правильного ответа для викторины"""
        query = update.callback_query
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                return ConversationHandler.END
            return ConversationHandler.END
        
        if query.data.startswith('correct_option_'):
            try:
                option_index = int(query.data.split('_')[2])
                poll_data = context.user_data.get('poll_data', {})
                options = poll_data.get('options', [])
                
                if 0 <= option_index < len(options):
                    poll_data['correct_option_id'] = option_index
                    
                    logger.info(f"✅ Выбран правильный вариант: {option_index + 1}")
                    
                    await query.message.edit_text(
                        f"✅ <b>Правильный вариант:</b> {option_index + 1}\n\n"
                        f"📝 <b>Вариант:</b> {options[option_index]}\n\n"
                        "📋 <b>Добавить объяснение?</b>\n\n"
                        "Объяснение будет показано после ответа.\n"
                        "Отправьте текст объяснения или <b>нет</b> для пропуска:",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.cancel_poll_button()
                    )
                    return States.WRITING_QUIZ_EXPLANATION
                else:
                    await query.message.edit_text(
                        "❌ <b>Неверный номер варианта!</b>\n\n"
                        "Выберите правильный вариант из списка:",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.select_correct_option(len(options))
                    )
                    return States.WRITING_QUIZ_CORRECT_ANSWER
                    
            except Exception as e:
                logger.error(f"Ошибка выбора правильного варианта: {e}")
                await query.message.edit_text(
                    "❌ <b>Ошибка выбора!</b>\n\n"
                    "Попробуйте еще раз:",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.poll_back_button()
                )
                return States.SELECTING_POLL_TYPE
        
        return States.WRITING_QUIZ_CORRECT_ANSWER

    @staticmethod
    async def receive_quiz_explanation(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение объяснения для викторины"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        poll_data = context.user_data.get('poll_data', {})
        explanation = update.message.text.strip()
        
        if explanation.lower() in ['нет', 'no', 'skip', 'пропустить', '-', '']:
            poll_data['explanation'] = None
            logger.info("📝 Объяснение пропущено")
        else:
            if len(explanation) > 200:
                explanation = explanation[:200] + "..."
            poll_data['explanation'] = explanation
            logger.info(f"📝 Получено объяснение: {explanation[:50]}...")
        
        await update.message.reply_text(
            "✅ <b>Настройки викторины сохранены!</b>\n\n"
            "📝 <b>Укажите тему сообщения:</b>\n\n"
            "• Отправьте <b>ID темы</b> (число)\n"
            "• Отправьте <b>ссылку на тему</b>\n"
            "• Отправьте <b>нет</b> для основной ленты",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.cancel_poll_button()
        )
        return States.SELECTING_POLL_TOPIC

    @staticmethod
    async def receive_poll_topic(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение темы для голосования"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        poll_data = context.user_data.get('poll_data', {})
        user_input = update.message.text.strip().lower()
        
        logger.info(f"Получена тема для голосования: {user_input}")
        
        if user_input in ['нет', 'no', 'skip', 'пропустить', 'основная', 'main', '0', 'основной', '']:
            poll_data['topic_id'] = None
            logger.info("📌 Основная лента (без темы)")
        else:
            topic_id = Utils.parse_topic_link(user_input)
            
            if topic_id is None:
                try:
                    topic_id = int(user_input)
                except ValueError:
                    await update.message.reply_text(
                        "❌ <b>Неверный формат темы!</b>\n\n"
                        "Отправьте:\n"
                        "• ID темы (число)\n"
                        "• Ссылку на тему\n"
                        "• 'нет' для основной ленты",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.cancel_poll_button()
                    )
                    return States.SELECTING_POLL_TOPIC
            
            if topic_id == 1:
                poll_data['topic_id'] = None
                logger.info("📌 Тема 1 -> основная лента")
            else:
                poll_data['topic_id'] = topic_id
                logger.info(f"📌 Тема: {topic_id}")
        
        logger.info("📤 Отправка голосования...")
        success = await Handlers.send_poll(context)
        
        if success:
            logger.info("✅ Голосование успешно отправлено")
            await update.message.reply_text(
                "✅ <b>Голосование успешно отправлено!</b>\n\n"
                "Используйте /create_poll для нового голосования",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        else:
            logger.error("❌ Ошибка при отправке голосования")
            await update.message.reply_text(
                "❌ <b>Ошибка при отправке голосования!</b>\n\n"
                "Проверьте:\n"
                "• Бот администратор в группе\n"
                "• Указана существующая тема\n"
                "• Все параметры корректны",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.main_menu()
            )
        
        context.user_data.pop('poll_data', None)
        return ConversationHandler.END

    @staticmethod
    async def send_poll(context: ContextTypes.DEFAULT_TYPE):
        """Отправка голосования"""
        poll_data = context.user_data.get('poll_data', {})
        chat_id = poll_data.get('telegram_chat_id')
        question = poll_data.get('question')
        options = poll_data.get('options', [])
        
        if not chat_id:
            logger.error("❌ Не указан chat_id")
            return False
        
        if not question:
            logger.error("❌ Не указан вопрос")
            return False
        
        if len(options) < 2:
            logger.error(f"❌ Мало вариантов ответа: {len(options)}")
            return False
        
        try:
            poll_params = {
                'chat_id': chat_id,
                'question': question,
                'options': options,
                'is_anonymous': poll_data.get('is_anonymous', False),
                'allows_multiple_answers': poll_data.get('allows_multiple_answers', False),
                'disable_notification': True
            }
            
            if poll_data.get('is_quiz'):
                poll_params['type'] = 'quiz'
            else:
                poll_params['type'] = 'regular'
            
            if poll_data.get('is_quiz'):
                correct_id = poll_data.get('correct_option_id')
                if correct_id is not None:
                    poll_params['correct_option_id'] = correct_id
                    logger.info(f"✅ Правильный ответ: {correct_id + 1}")
                
                explanation = poll_data.get('explanation')
                if explanation:
                    poll_params['explanation'] = explanation[:200]
                    logger.info(f"📝 Объяснение: {explanation[:30]}...")
            
            if poll_data.get('topic_id'):
                poll_params['message_thread_id'] = poll_data['topic_id']
                logger.info(f"📌 Тема: {poll_data['topic_id']}")
            
            possible_chat_ids = Utils.get_possible_chat_ids(chat_id)
            last_error = None
            
            for try_chat_id in possible_chat_ids:
                try:
                    poll_params['chat_id'] = try_chat_id
                    logger.info(f"📤 Отправка голосования в chat_id={try_chat_id}")
                    
                    result = await context.bot.send_poll(**poll_params)
                    logger.info(f"✅ Голосование отправлено! ID: {result.message_id}")
                    return True
                    
                except BadRequest as e:
                    error_msg = str(e).lower()
                    last_error = error_msg
                    logger.warning(f"⚠️ Ошибка с chat_id={try_chat_id}: {error_msg}")
                    
                    if "message thread not found" in error_msg and poll_params.get('message_thread_id'):
                        try:
                            del poll_params['message_thread_id']
                            logger.info(f"📤 Пробую без темы в chat_id={try_chat_id}")
                            result = await context.bot.send_poll(**poll_params)
                            logger.info(f"✅ Голосование отправлено без темы")
                            return True
                        except Exception as e2:
                            logger.warning(f"⚠️ Ошибка без темы: {e2}")
                            continue
                    
                    if "chat not found" in error_msg:
                        logger.warning(f"⚠️ Чат не найден: {try_chat_id}")
                        continue
                    
                    continue
                    
                except Exception as e:
                    last_error = str(e)
                    logger.warning(f"⚠️ Другая ошибка с chat_id={try_chat_id}: {e}")
                    continue
            
            logger.error(f"❌ Не удалось отправить голосование. Ошибка: {last_error}")
            return False
            
        except Exception as e:
            logger.error(f"❌ Критическая ошибка отправки голосования: {e}")
            return False

    @staticmethod
    async def cancel_poll(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отмена создания голосования"""
        user = update.effective_user
        query = update.callback_query
        
        if query:
            try:
                await query.answer()
            except:
                pass
            
            logger.info(f"Пользователь {user.id} отменил создание голосования")
            await query.message.edit_text(
                "❌ Создание голосования отменено",
                reply_markup=Keyboards.main_menu()
            )
        else:
            logger.info(f"Пользователь {user.id} отменил создание голосования")
            await update.message.reply_text(
                "❌ Создание голосования отменено",
                reply_markup=Keyboards.main_menu()
            )
        
        if 'poll_data' in context.user_data:
            context.user_data.pop('poll_data', None)
        
        return ConversationHandler.END
    
    @staticmethod
    async def go_back_to_poll_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат к выбору типа голосования"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        await query.answer()
        
        poll_data = context.user_data.get('poll_data', {})
        options = poll_data.get('options', [])
        options_list = "\n".join([f"{i+1}. {opt}" for i, opt in enumerate(options)])
        
        await query.message.edit_text(
            f"✅ <b>Варианты ответов:</b>\n\n{options_list}\n\n"
            "Выберите тип голосования:",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.poll_type_selection()
        )
        return States.SELECTING_POLL_TYPE
    
    @staticmethod
    async def go_back_to_poll_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат к вводу вариантов ответов"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        await query.answer()
        
        await query.message.edit_text(
            "Напишите варианты ответов, каждый с новой строки:\n\n"
            "<b>Пример:</b>\n"
            "Новую функцию А\n"
            "Новую функцию Б\n"
            "Исправить баги\n"
            "Ничего не менять\n\n"
            "<i>Можно добавить до 10 вариантов ответа</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.cancel_poll_button()
        )
        return States.WRITING_POLL_OPTIONS
    
    
    @staticmethod
    async def delete_post_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Команда /deletepost - удаление сообщения"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context,
                update.message if update.message else (update.callback_query.message if update.callback_query else None))
        
        if update.callback_query:
            query = update.callback_query
            message = query.message
            try:
                await query.answer()
            except:
                pass
        else:
            message = update.message
        
        logger.info(f"Начало удаления сообщения")
        
        await message.reply_text(
            "🗑️ <b>Удаление сообщения</b>\n\n"
            "Отправьте ссылку на сообщение, которое нужно удалить:\n\n"
            "<b>Форматы ссылок:</b>\n"
            "• https://t.me/c/1234567890/12345 - приватные группы\n"
            "• https://t.me/c/1234567890/1/12345 - с указанием темы\n"
            "<b>Пример:</b>\n"
            "<code>https://t.me/c/2819799004/1/21134</code>\n\n"
            "<i>⚠️ Бот должен быть администратором в чате!</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.cancel_button()
        )
        return States.DELETE_POST
    
    @staticmethod
    async def receive_delete_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Получение ссылки для удаления"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context, update.message)
        
        message_link = update.message.text.strip()
        
        try:
            link_info = Utils.parse_message_link(message_link)
            
            if not link_info:
                await update.message.reply_text(
                    "❌ <b>Неверная ссылка!</b>\n\n"
                    "Пожалуйста, отправьте корректную ссылку на сообщение.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.cancel_button()
                )
                return States.DELETE_POST
            
            context.user_data['delete_info'] = link_info
            
            preview_text = (
                f"🔍 <b>Подтверждение удаления</b>\n\n"
                f"📋 <b>Информация о сообщении:</b>\n"
                f"• ID чата: {link_info.get('chat_id', 'Неизвестно')}\n"
                f"• ID сообщения: {link_info.get('message_id', 'Неизвестно')}\n"
            )
            
            if link_info.get('topic_id'):
                preview_text += f"• ID темы: {link_info.get('topic_id')}\n"
            
            preview_text += "\n<i>⚠️ Убедитесь, что бот имеет права администратора!</i>\n\n"
            preview_text += "Вы уверены, что хотите удалить это сообщение?"
            
            logger.info(f"Получена ссылка для удаления: {message_link}")
            
            await update.message.reply_text(
                preview_text,
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.confirm_delete()
            )
            return States.CONFIRM_DELETE
            
        except Exception as e:
            logger.error(f"Ошибка обработки ссылки для удаления: {e}")
            await update.message.reply_text(
                f"❌ <b>Ошибка обработки ссылки:</b> {str(e)[:100]}\n\n"
                "Попробуйте еще раз:",
                parse_mode=ParseMode.HTML,
                reply_markup=Keyboards.cancel_button()
            )
            return States.DELETE_POST
    
    @staticmethod
    async def delete_message_safe(bot, original_chat_id, message_id, user_id=None):
        """Безопасное удаление сообщения"""
        formats_to_try = []
        
        formats_to_try.append(original_chat_id)
        formats_to_try.append(-original_chat_id)
        
        formats_to_try.append(Utils.convert_to_telegram_chat_id(original_chat_id))
        formats_to_try.append(-Utils.convert_to_telegram_chat_id(abs(original_chat_id)))
        
        if user_id:
            user_groups = db.get_user_groups(user_id)
            for group_db_id, _ in user_groups:
                formats_to_try.append(group_db_id)
                formats_to_try.append(-group_db_id)
                formats_to_try.append(Utils.convert_to_telegram_chat_id(group_db_id))
        
        formats_to_try = list(set(formats_to_try))
        
        logger.info(f"Пробую форматы chat_id для удаления: {formats_to_try}")
        
        for try_chat_id in formats_to_try:
            try:
                await bot.delete_message(
                    chat_id=try_chat_id,
                    message_id=message_id
                )
                logger.info(f"✅ Сообщение удалено с chat_id={try_chat_id}")
                return True
            except BadRequest as e:
                error_msg = str(e).lower()
                continue
            except Exception as e:
                continue
        
        return False
    
    @staticmethod
    async def confirm_delete_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Подтверждение удаления"""
        if not context.user_data.get('authorized'):
            return await Handlers.require_auth(update, context)
        
        query = update.callback_query
        
        try:
            await query.answer()
        except:
            pass
        
        action = query.data
        message_info = context.user_data.get('delete_info', {})
        
        if action == 'confirm_delete':
            try:
                await query.message.edit_text("🗑️ Пробую удалить сообщение...")
                
                chat_id = message_info.get('chat_id')
                message_id = message_info.get('message_id')
                
                if not chat_id or not message_id:
                    await query.message.edit_text(
                        "❌ <b>Не удалось получить информацию о сообщении!</b>",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.main_menu()
                    )
                    return ConversationHandler.END
                
                logger.info(f"Пробую удалить chat_id={chat_id}, message_id={message_id}")
                
                user_id = update.effective_user.id if update.effective_user else None
                success = await Handlers.delete_message_safe(
                    context.bot, 
                    chat_id, 
                    message_id, 
                    user_id
                )
                
                if success:
                    logger.info("✅ Сообщение успешно удалено")
                    await query.message.edit_text(
                        "✅ <b>Сообщение успешно удалено!</b>",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.main_menu()
                    )
                else:
                    logger.warning(f"Не могу удалить сообщение {message_id} в чате {chat_id}")
                    await query.message.edit_text(
                        "❌ <b>Не могу удалить сообщение!</b>\n\n"
                        f"<b>Возможные причины:</b>\n"
                        f"1. Бот не является участником чата\n"
                        f"2. Бот не имеет прав администратора\n"
                        f"3. Сообщение уже удалено\n"
                        f"4. Сообщение слишком старое\n\n"
                        f"<b>ID сообщения:</b> {message_id}\n"
                        f"<b>ID чата из ссылки:</b> {chat_id}",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.main_menu()
                    )
                    
            except Exception as e:
                logger.error(f"Общая ошибка при удалении: {e}")
                await query.message.edit_text(
                    "❌ <b>Ошибка при удалении!</b>\n"
                    f"Ошибка: {str(e)[:100]}\n\n"
                    "Проверьте права бота в группе.",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.main_menu()
                )
            
            if 'delete_info' in context.user_data:
                context.user_data.pop('delete_info', None)
                
        elif action == 'cancel_delete':
            logger.info("Удаление отменено пользователем")
            await query.message.edit_text(
                "❌ Удаление отменено",
                reply_markup=Keyboards.main_menu()
            )
        
        return ConversationHandler.END
    
    
    @staticmethod
    async def handle_group_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка команд в группе (доступно всем авторизованным)"""
        message = update.message
        
        if not message or not message.text:
            return
        
        if message.chat.type not in ['group', 'supergroup']:
            return
        
        user = message.from_user
        if not user:
            return
        
        text = message.text.strip()
        chat_id = message.chat.id
        chat_title = message.chat.title
        
        logger.info(f"📨 Сообщение в группе '{chat_title}' от {user.id}: {text}")
        
        if text.lower() == 'help' or text.startswith('/help'):
            return await Handlers.help_command(update, context)
        
        if text.startswith('/bind_group'):
            return await Handlers.bind_group_command(update, context)
        
        if not context.user_data.get('authorized') and not db.is_user_authorized(user.id):
            logger.warning(f"⛔ Пользователь {user.id} не авторизован для команд в группе")
            return
        
        patterns = [
            r'botcmd\s*-g\s*addp\s*\{post="([^"]+)"\}',
            r'botcmd\s*-g\s*addp\s*\{post="([^"]*)"\}',
            r'botcmd\s*-g\s*addp\s*\{post\s*=\s*"([^"]+)"\}',
            r'botcmd\s*-g\s*addp\s*\{post\s*=\s*"([^"]*)"\}',
            r'botcmd\s*-g\s*addp\s*\{post=([^}]+)\}',
            r'botcmd\s*-g\s*addp\s*\{post=([^}]*)\}',
        ]
        
        post_text = None
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                post_text = match.group(1).strip()
                if post_text.startswith('"') and post_text.endswith('"'):
                    post_text = post_text[1:-1]
                logger.info(f"✅ Найдена команда addp")
                break
        
        if post_text is not None:
            logger.info(f"📝 Команда addp от {user.id}: '{post_text}'")
            
            try:
                if not post_text:
                    await message.reply_text("❌ Текст поста не может быть пустым!", 
                                            disable_notification=True)
                    return
                
                formatted_text = Utils.parse_markdown_to_html(post_text)
                
                sent_message = await context.bot.send_message(
                    chat_id=chat_id,
                    text=formatted_text,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                    disable_notification=True
                )
                
                logger.info(f"✅ Текстовый пост отправлен. ID сообщения: {sent_message.message_id}")
                
                try:
                    await context.bot.delete_message(
                        chat_id=chat_id,
                        message_id=message.message_id
                    )
                    logger.info(f"✅ Сообщение команды удалено")
                except Exception as delete_error:
                    logger.warning(f"⚠️ Не удалось удалить сообщение команды: {delete_error}")
                
            except BadRequest as e:
                if "can't parse entities" in str(e).lower():
                    try:
                        sent_message = await context.bot.send_message(
                            chat_id=chat_id,
                            text=post_text,
                            parse_mode=None,
                            disable_web_page_preview=True,
                            disable_notification=True
                        )
                        logger.info(f"✅ Текст отправлен без HTML форматирования")
                    except Exception as e2:
                        logger.error(f"❌ Ошибка отправки поста без HTML: {e2}")
                else:
                    logger.error(f"❌ Ошибка отправки поста: {e}")
            except Exception as e:
                logger.error(f"❌ Ошибка отправки поста: {e}", exc_info=True)
        else:
            logger.info(f"📋 Текст не распознан как команда addp")
        
        return ConversationHandler.END
    
    
    @staticmethod
    async def go_back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат в главное меню"""
        query = update.callback_query
        
        if query:
            try:
                await query.answer()
            except Exception as e:
                if "Query is too old" not in str(e):
                    logger.error(f"Ошибка ответа на запрос: {e}")
            
            try:
                await query.message.edit_text(
                    "👋 <b>Аноним Бот</b> - быстрый бот для анонимных постов!\n\n"
                    "⚡ <b>Используйте меню:</b>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.main_menu()
                )
            except Exception as e:
                logger.error(f"Ошибка редактирования сообщения: {e}")
                await query.message.reply_text(
                    "👋 <b>Аноним Бот</b> - быстрый бот для анонимных постов!\n\n"
                    "⚡ <b>Используйте меню:</b>",
                    parse_mode=ParseMode.HTML,
                    reply_markup=Keyboards.main_menu()
                )
        
        if 'post_data' in context.user_data:
            context.user_data.pop('post_data', None)
        if 'poll_data' in context.user_data:
            context.user_data.pop('poll_data', None)
        if 'delete_info' in context.user_data:
            context.user_data.pop('delete_info', None)
        
        return ConversationHandler.END
    
    @staticmethod
    async def go_back_to_post_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат к выбору типа поста"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" not in str(e):
                logger.error(f"Ошибка ответа на запрос: {e}")
        
        post_data = context.user_data.get('post_data', {})
        
        await query.message.edit_text(
            f"✅ <b>Группа выбрана:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
            "Выберите тип поста:",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.post_type_selection()
        )
        return States.SELECTING_POST_TYPE
    
    @staticmethod
    async def go_back_to_button_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат к выбору кнопок"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" not in str(e):
                logger.error(f"Ошибка ответа на запрос: {e}")
        
        post_data = context.user_data.get('post_data', {})
        
        await query.message.edit_text(
            f"✅ <b>Группа выбрана:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
            "Добавить кнопки под постом?",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.button_options()
        )
        return States.SELECTING_BUTTON_OPTION
    
    @staticmethod
    async def go_back_to_mention_options(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Возврат к выбору упоминаний"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" not in str(e):
                logger.error(f"Ошибка ответа на запрос: {e}")
        
        post_data = context.user_data.get('post_data', {})
        
        await query.message.edit_text(
            f"✅ <b>Группа выбрана:</b> {post_data.get('group_title', 'Неизвестно')}\n\n"
            "Хотите упомянуть участников группы?",
            parse_mode=ParseMode.HTML,
            reply_markup=Keyboards.mention_options()
        )
        return States.SELECTING_MENTION_OPTION
    
    @staticmethod
    async def cancel_post(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Отмена создания поста"""
        user = update.effective_user
        query = update.callback_query
        
        if query:
            try:
                await query.answer()
            except:
                pass
            
            logger.info(f"Пользователь {user.id} отменил создание поста")
            try:
                await query.message.edit_text(
                    "❌ Создание поста отменено",
                    reply_markup=Keyboards.main_menu()
                )
            except:
                await query.message.reply_text(
                    "❌ Создание поста отменено",
                    reply_markup=Keyboards.main_menu()
                )
        else:
            logger.info(f"Пользователь {user.id} отменил создание поста")
            await update.message.reply_text(
                "❌ Создание поста отменено",
                reply_markup=Keyboards.main_menu()
            )
        
        if 'post_data' in context.user_data:
            context.user_data.pop('post_data', None)
        
        return ConversationHandler.END
    
    
    @staticmethod
    def create_inline_keyboard(buttons_data):
        """Создает InlineKeyboardMarkup из данных кнопок"""
        if not buttons_data:
            return None
        
        try:
            if isinstance(buttons_data, str):
                import ast
                buttons_data = ast.literal_eval(buttons_data)
            
            keyboard = []
            for button in buttons_data:
                text = button['text']
                url = button['url']
                
                keyboard.append([InlineKeyboardButton(
                    text=text,
                    url=url
                )])
            
            return InlineKeyboardMarkup(keyboard)
        except Exception as e:
            logger.error(f"❌ Ошибка создания клавиатуры: {e}")
            return None

    @staticmethod
    def prepare_message_text(post_data):
        """Подготавливает текст сообщения с форматированием"""
        text = ""
        
        if post_data.get('mentions_text'):
            text += post_data['mentions_text']
        
        if post_data.get('type') == 'reply':
            main_text = post_data.get('reply_text', '')
        else:
            main_text = post_data.get('text', '')
        
        if main_text:
            if post_data.get('formatted_text'):
                formatted_text = post_data['formatted_text']
            elif post_data.get('entities'):
                formatted_text = Utils.parse_message_entities(main_text, post_data['entities'])
            else:
                formatted_text = Utils.parse_markdown_to_html(main_text)
            text += formatted_text
        
        return text.strip()
    
    @staticmethod
    async def send_post(context: ContextTypes.DEFAULT_TYPE):
        """Универсальная отправка поста"""
        post_data = context.user_data.get('post_data', {})
        group_id = post_data.get('group_id')
        post_type = post_data.get('type', 'text')
        
        reply_markup = None
        if post_data.get('has_buttons') and post_data.get('buttons'):
            reply_markup = Handlers.create_inline_keyboard(post_data['buttons'])
        
        try:
            if post_type == 'text':
                telegram_chat_id = post_data.get('telegram_chat_id', group_id)
                topic_id = post_data.get('topic_id')
                
                if topic_id == 1:
                    topic_id = None
                
                if post_data.get('use_copy') and post_data.get('copy_message'):
                    copy_params = {
                        'chat_id': telegram_chat_id,
                        'from_chat_id': post_data['copy_message']['chat_id'],
                        'message_id': post_data['copy_message']['message_id'],
                        'disable_notification': True
                    }
                    
                    if topic_id:
                        copy_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        copy_params['reply_markup'] = reply_markup
                    
                    await context.bot.copy_message(**copy_params)
                    logger.info(f"✅ Сообщение с Premium эмодзи скопировано целиком")
                    return True
                
                elif post_data.get('media_type') == 'sticker' and post_data.get('sticker_file_id'):
                    sticker_params = {
                        'chat_id': telegram_chat_id,
                        'sticker': post_data['sticker_file_id'],
                        'disable_notification': True
                    }
                    
                    if topic_id:
                        sticker_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        sticker_params['reply_markup'] = reply_markup
                    
                    await context.bot.send_sticker(**sticker_params)
                    logger.info(f"✅ Стикер отправлен")
                    
                    if post_data.get('text'):
                        caption_params = {
                            'chat_id': telegram_chat_id,
                            'text': post_data['text'],
                            'disable_web_page_preview': True,
                            'disable_notification': True
                        }
                        if post_data.get('entities'):
                            caption_params['entities'] = post_data['entities']
                        if topic_id:
                            caption_params['message_thread_id'] = topic_id
                        
                        await context.bot.send_message(**caption_params)
                        logger.info("✅ Подпись к стикеру отправлена")
                    
                    return True
                
                elif post_data.get('has_media') and post_data.get('media'):
                    media_info = post_data.get('media', {})
                    from_chat_id = media_info.get('chat_id')
                    message_id = media_info.get('message_id')
                    
                    copy_params = {
                        'chat_id': telegram_chat_id,
                        'from_chat_id': from_chat_id,
                        'message_id': message_id,
                        'disable_notification': True
                    }
                    
                    if post_data.get('text'):
                        copy_params['caption'] = post_data['text']
                        if post_data.get('entities'):
                            copy_params['caption_entities'] = post_data['entities']
                    
                    if topic_id:
                        copy_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        copy_params['reply_markup'] = reply_markup
                    
                    await context.bot.copy_message(**copy_params)
                    logger.info(f"✅ Медиа скопировано")
                    return True
                
                elif post_data.get('entities'):
                    params = {
                        'chat_id': telegram_chat_id,
                        'text': post_data.get('text', ''),
                        'entities': post_data['entities'],
                        'disable_web_page_preview': True,
                        'disable_notification': True
                    }
                    
                    if topic_id:
                        params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        params['reply_markup'] = reply_markup
                    
                    await context.bot.send_message(**params)
                    logger.info(f"✅ Текст с форматированием отправлен")
                    return True
                
                else:
                    params = {
                        'chat_id': telegram_chat_id,
                        'text': post_data.get('text', ''),
                        'disable_web_page_preview': True,
                        'disable_notification': True
                    }
                    
                    if topic_id:
                        params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        params['reply_markup'] = reply_markup
                    
                    await context.bot.send_message(**params)
                    logger.info(f"✅ Текст отправлен")
                    return True
            
            elif post_type == 'forward':
                forward_info = post_data.get('forward_message', {})
                from_chat_id = forward_info.get('chat_id')
                message_id = forward_info.get('message_id')
                telegram_chat_id = post_data.get('telegram_chat_id', group_id)
                topic_id = post_data.get('topic_id')
                
                if topic_id == 1:
                    topic_id = None
                
                copy_params = {
                    'chat_id': telegram_chat_id,
                    'from_chat_id': from_chat_id,
                    'message_id': message_id,
                    'disable_notification': True
                }
                
                if topic_id:
                    copy_params['message_thread_id'] = topic_id
                
                await context.bot.copy_message(**copy_params)
                logger.info("✅ Сообщение скопировано")
                
                if post_data.get('mentions_text'):
                    try:
                        mention_params = {
                            'chat_id': telegram_chat_id,
                            'text': post_data['mentions_text'],
                            'parse_mode': ParseMode.HTML,
                            'disable_notification': True
                        }
                        if topic_id:
                            mention_params['message_thread_id'] = topic_id
                        await context.bot.send_message(**mention_params)
                    except Exception as e:
                        logger.error(f"❌ Ошибка упоминаний: {e}")
                
                if reply_markup:
                    try:
                        button_params = {
                            'chat_id': telegram_chat_id,
                            'text': "⬇️",
                            'disable_notification': True
                        }
                        if topic_id:
                            button_params['message_thread_id'] = topic_id
                        button_params['reply_markup'] = reply_markup
                        await context.bot.send_message(**button_params)
                    except Exception as e:
                        logger.error(f"❌ Ошибка кнопок: {e}")
                
                return True
            
            elif post_type == 'reply':
                link_info = post_data.get('reply_link', {})
                reply_to_message_id = link_info.get('message_id')
                telegram_chat_id = post_data.get('telegram_chat_id', group_id)
                topic_id = post_data.get('topic_id') or link_info.get('topic_id')
                
                if topic_id == 1:
                    topic_id = None
                
                if post_data.get('use_copy') and post_data.get('copy_message'):
                    copy_params = {
                        'chat_id': telegram_chat_id,
                        'from_chat_id': post_data['copy_message']['chat_id'],
                        'message_id': post_data['copy_message']['message_id'],
                        'disable_notification': True
                    }
                    
                    if reply_to_message_id:
                        copy_params['reply_to_message_id'] = reply_to_message_id
                    
                    if topic_id:
                        copy_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        copy_params['reply_markup'] = reply_markup
                    
                    await context.bot.copy_message(**copy_params)
                    logger.info("✅ Ответ с Premium эмодзи отправлен")
                    return True
                
                elif post_data.get('has_media') and post_data.get('media'):
                    media_info = post_data.get('media', {})
                    from_chat_id = media_info.get('chat_id')
                    media_message_id = media_info.get('message_id')
                    
                    copy_params = {
                        'chat_id': telegram_chat_id,
                        'from_chat_id': from_chat_id,
                        'message_id': media_message_id,
                        'disable_notification': True
                    }
                    
                    if post_data.get('reply_text'):
                        copy_params['caption'] = post_data['reply_text']
                        if post_data.get('entities'):
                            copy_params['caption_entities'] = post_data['entities']
                    
                    if reply_to_message_id:
                        copy_params['reply_to_message_id'] = reply_to_message_id
                    
                    if topic_id:
                        copy_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        copy_params['reply_markup'] = reply_markup
                    
                    await context.bot.copy_message(**copy_params)
                    logger.info("✅ Ответ с медиа отправлен")
                    return True
                
                elif post_data.get('reply_text'):
                    text_params = {
                        'chat_id': telegram_chat_id,
                        'text': post_data['reply_text'],
                        'disable_web_page_preview': True,
                        'disable_notification': True
                    }
                    
                    if post_data.get('entities'):
                        text_params['entities'] = post_data['entities']
                    
                    if reply_to_message_id:
                        text_params['reply_to_message_id'] = reply_to_message_id
                    
                    if topic_id:
                        text_params['message_thread_id'] = topic_id
                    
                    if reply_markup:
                        text_params['reply_markup'] = reply_markup
                    
                    await context.bot.send_message(**text_params)
                    logger.info("✅ Текстовый ответ отправлен")
                    return True
                
                return False
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Общая ошибка отправки: {e}")
            return False

    @staticmethod
    async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Общий обработчик callback запросов"""
        query = update.callback_query
        
        if not query:
            return ConversationHandler.END
        
        try:
            await query.answer()
        except Exception as e:
            if "Query is too old" in str(e):
                logger.debug(f"Пропускаем устаревший запрос")
                return ConversationHandler.END
            return ConversationHandler.END
        
        data = query.data
        logger.info(f"📩 Callback: {data}")
        
        if data == 'back_to_main':
            return await Handlers.go_back_to_main(update, context)
        
        if data == '/help':
            return await Handlers.help_command(update, context)
        
        if not context.user_data.get('authorized'):
            await query.answer("🔒 Требуется авторизация! Используйте /start", show_alert=True)
            return ConversationHandler.END
        
        if data == '/create_post':
            return await Handlers.create_post_command(update, context)
        elif data == '/create_poll':
            return await Handlers.create_poll_command(update, context)
        elif data == '/my_groups':
            return await Handlers.my_groups_command(update, context)
        elif data == '/deletepost':
            return await Handlers.delete_post_command(update, context)
        elif data == 'back_to_post_type':
            return await Handlers.go_back_to_post_type(update, context)
        elif data == 'back_to_button_selection':
            return await Handlers.go_back_to_button_selection(update, context)
        elif data == 'back_to_mention_options':
            return await Handlers.go_back_to_mention_options(update, context)
        elif data == 'back_to_poll_type':
            return await Handlers.go_back_to_poll_type(update, context)
        elif data == 'back_to_poll_options':
            return await Handlers.go_back_to_poll_options(update, context)
        elif data == 'cancel_post':
            return await Handlers.cancel_post(update, context)
        elif data == 'cancel_poll':
            return await Handlers.cancel_poll(update, context)
        elif data in ['confirm_delete', 'cancel_delete']:
            return await Handlers.confirm_delete_action(update, context)
        elif data.startswith('select_group_post_'):
            return await Handlers.select_group_for_post(update, context)
        elif data.startswith('select_group_poll_'):
            return await Handlers.select_group_for_poll(update, context)
        elif data.startswith('post_type_'):
            return await Handlers.select_post_type(update, context)
        elif data.startswith('poll_type_'):
            return await Handlers.select_poll_type(update, context)
        elif data.startswith('button_'):
            return await Handlers.select_button_option(update, context)
        elif data.startswith('mention_'):
            return await Handlers.select_mention_option(update, context)
        elif data.startswith('role_') or data == 'no_roles':
            return await Handlers.select_role_for_mention(update, context)
        elif data.startswith('correct_option_'):
            return await Handlers.select_correct_option(update, context)
        elif data.startswith('group_info_'):
            try:
                group_id = int(data.split('_')[2])
                group_info = db.get_group_info(group_id)
                if group_info:
                    await query.message.edit_text(
                        f"📋 <b>Информация о группе:</b>\n\n"
                        f"🏷️ <b>Название:</b> {group_info[1]}\n"
                        f"🆔 <b>ID:</b> {group_id}\n\n"
                        f"ℹ️ <b>Действия:</b>",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.create_post_button(group_id)
                    )
            except Exception as e:
                logger.error(f"Ошибка обработки group_info: {e}")
            return ConversationHandler.END
        elif data.startswith('create_post_'):
            try:
                group_id = int(data.split('_')[2])
                group_info = db.get_group_info(group_id)
                if group_info:
                    context.user_data['post_data'] = {
                        'group_id': group_id,
                        'group_title': group_info[1],
                        'type': None,
                        'telegram_chat_id': Utils.convert_to_telegram_chat_id(group_id)
                    }
                    await query.message.edit_text(
                        f"✅ <b>Группа выбрана:</b> {group_info[1]}\n\n"
                        "Выберите тип поста:",
                        parse_mode=ParseMode.HTML,
                        reply_markup=Keyboards.post_type_selection()
                    )
                    return States.SELECTING_POST_TYPE
            except Exception as e:
                logger.error(f"Ошибка обработки create_post: {e}")
                await query.message.reply_text("❌ Ошибка!")
            return ConversationHandler.END
        
        return ConversationHandler.END